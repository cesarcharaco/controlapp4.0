<?php $__env->startSection('content'); ?>

        <style type="text/css">
        .card {
            border: 1px solid #f6f6f7!important;
            border-color: #ff3e36 !important;
        }
        .palabraVerInmueble2, .palabraVerEstaciona2,.PalabraEditarPago2, .tituloTabla2
        {
            display: none;
        }
        @media  only screen and (max-width: 800px)  {

            .PalabraEditarPago, .PalabraRealizarPago, .PalabraPagoConfirmar{
                display: none;
            }
            .palabraVerInmueble{
                display: none;
            }
            .palabraVerInmueble2{
                display: block;
            }
            .palabraVerEstaciona{
                display: none;
            }
            .palabraVerEstaciona2{
                display: block;
            }
            .PalabraEditarPago2{
                display: block;
            }
            .iconosMetaforas{
                display: none;    
            }
            .card-table{
                width: 100%
            }

        }
        @media  only screen and (max-width: 200px)  {
            .botonesEditEli{
                width: 15px;
                height: 15px;
            }
            .iconosMetaforas2{
                width: 5px;
                height: 5px;    
            }
        }
        @media  screen and (max-width: 480px) {
            .tituloTabla{
                display: none;
            }
            .tituloTabla2{
                display: block;
            }
            .iconosMetaforas2{
                width: 15px;
                height: 15px;    
            }
            .botonesEditEli{
                width: 30px;
                height: 30px;
                margin-top: 5px;
                    
            }
        }


    </style>
    <div class="container">
        <input type="hidden" id="colorView" value="#ff3e36 !important">
        <div class="row page-title">
            <div class="col-md-12">
                <nav aria-label="breadcrumb" class="float-right mt-1">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Multas/Recargas</li>
                    </ol>
                </nav>
                <h4 class="mb-1 mt-0">Multas/Recargas</h4>
            </div>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(count($errors)): ?>
            <div class="alert-list m-4">
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="card border border-danger rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="display: none;">
            <div class="row justify-content-center">
                <?php if(\Auth::user()->tipo_usuario == 'Admin'): ?>
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 offset-md-12">
                                <a class="btn btn-warning boton-tabla shadow" data-toggle="modal" data-target="#AsignarMR" onclick="asignar_mr()" style="
                                    border-radius: 10px;
                                    color: white;
                                    height: 35px;
                                    margin-bottom: 5px;
                                    margin-top: 5px;
                                    float: right;
                                    border: 1px solid #f6f6f7!important;
                                    border-color: #35e930  !important;
                                    background-color: #35e930  !important;">
                                    <span class="PalabraEditarPago "><strong>Asignar M/R</strong>   </span>
                                    <center>
                                        <span class="PalabraEditarPago2 ">
                                            <i data-feather="plus" class="iconosMetaforas2"></i>
                                        </span>
                                    </center>
                                </a>
                                <a class="btn btn-success boton-tabla shadow" data-toggle="modal" data-target="#crearMulta" onclick="asignar_mr()" style="
                                    border-radius: 10px;
                                    color: white;
                                    height: 35px;
                                    margin-bottom: 5px;
                                    margin-top: 5px;
                                    float: right;
                                    border: 1px solid #f6f6f7!important;
                                    border-color: #ff3e36 !important;
                                    background-color: #ff3e36 !important;">
                                    <span class="PalabraEditarPago "><strong>Nuevo Multa/Recarga</strong>   </span>
                                    <center>
                                        <span class="PalabraEditarPago2 ">
                                            <i data-feather="key" class="iconosMetaforas2"></i>
                                        </span>
                                    </center>
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
    
            <div class="col-md-12">
                <table class="table dataTable data-table-basic table-curved table-striped tabla-estilo" style="width: 100%;">
                    <thead>
                        <?php if(\Auth::user()->tipo_usuario == 'Admin'): ?>
                            <tr class="table-default text-white">
                                <td colspan="5" align="center">
                                    <div class="card border border-danger" style="" role="alert">
                                        <span class="text-dark p-1 mb-1"><strong>Aviso: </strong><br>-Seleccione a una multa/recarga para ver mas opciones.</span>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <tr class="bg-primary text-white" id="th2" style="display: none">
                            <th width="10">
                            </th>
                            <th>
                                <span class="PalabraEditarPago">Motivo</span>
                                <span class="PalabraEditarPago2">M</span>
                            </th>
                            <th colspan="2" align="center">
                                <center>
                                    <span class="PalabraEditarPago">Opciones</span>
                                    <span class="PalabraEditarPago2">O</span>
                                </center>
                            </th>
                            <th><span class="PalabraEditarPago">Asignados</span>
                                <span class="PalabraEditarPago2">A</span></th>
                        </tr>
                        <tr class="text-white" id="th1" style="background-color: #ff3e36 !important;">
                            <th>#</th>
                            <th>
                                <span class="PalabraEditarPago" align="center">Motivo</span>
                                <span class="PalabraEditarPago2" align="center">M</span>
                            </th>
                            <th>
                                <span class="PalabraEditarPago" align="center">Observación</span>
                                <span class="PalabraEditarPago2" align="center">O</span>
                            </th>
                            <th>
                                <span class="PalabraEditarPago" align="center">Monto</span>
                                <span class="PalabraEditarPago2" align="center">$</span>
                            </th>
                            <th>
                                <span class="PalabraEditarPago" align="center">Tipo</span>
                                <span class="PalabraEditarPago2" align="center">T</span>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $num=0; ?>
                        <?php if(\Auth::user()->tipo_usuario == 'Admin'): ?>
                            <?php $__currentLoopData = $mr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="vista1-<?php echo e($key->id); ?>" onclick="opcionesTabla(1,'<?php echo e($key->id); ?>')">
                                    <td align="center"><?php echo e($num=$num+1); ?></td>
                                    <td><?php echo e($key->motivo); ?></td>
                                    <td><?php echo e($key->observacion); ?></td>
                                    <td><?php echo e($key->monto); ?></td>
                                    <td><?php echo e($key->tipo); ?></td>
                                </tr>
                                <tr id="vista2-<?php echo e($key->id); ?>" class="table-success" style="display: none;">
                                    <td width="10">
                                        <button class="btn btn-success btn-sm boton-tabla shadow botonesEditEli" onclick="opcionesTabla(2,'<?php echo e($key->id); ?>')">
                                            <span class="PalabraEditarPago ">Regresar</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="arrow-left" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </button>
                                    </td>
                                    <td>
                                        <span><?php echo e($key->motivo); ?></span>
                                    </td>
                                    <td colspan="2" align="center">
                                        <a href="#" class="btn btn-warning btn-sm boton-tabla shadow botonesEditEli" data-toggle="modal" data-target="#editarMulta" onclick="EditarMR('<?php echo e($key->id); ?>','<?php echo e($key->motivo); ?>','<?php echo e($key->monto); ?>','<?php echo e($key->tipo); ?>','<?php echo e($key->observacion); ?>')" >
                                            <span class="PalabraEditarPago ">Editar</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="edit" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </a>

                                        <a href="#" class="btn btn-danger btn-sm boton-tabla shadow botonesEditEli"data-toggle="modal" data-target="#eliminarMulta" onclick="eliminar('<?php echo e($key->id); ?>')" class="btn btn-danger btn-sm">
                                            <span class="PalabraEditarPago ">Eliminar</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="trash" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </a>

                                        
                                    </td>
                                    <td style="display: none"></td>
                                    <td>
                                        <a href="#" class="btn btn-info btn-sm boton-tabla shadow botonesEditEli" onclick="verAsignados('<?php echo e($key->id); ?>')" class="btn btn-danger btn-sm">
                                            <span class="PalabraEditarPago ">Ver Asignados</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="eye" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </a>
                                    </td>
                                    

                                </tr>
                                <tr style="display: none;">
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $asignacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <button class="btn btn-warning rounded btn-sm" onclick="editarReferencia('<?php echo e($key->id); ?>','<?php echo e($key->id_pivot); ?>');">
                                            <span class="PalabraEditarPago" align="center">Editar Código de Trans.</span>
                                            <span class="PalabraEditarPago2" align="center">
                                                <i data-feather="edit" class="iconosMetaforas2"></i>
                                            </span>
                                        </button>
                                    </td>
                                    <td><?php echo e($key->motivo); ?></td>
                                    <td><?php echo e($key->observacion); ?></td>
                                    <td><?php echo e($key->monto); ?></td>
                                    <td><?php echo e($key->tipo); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        
                    </tbody>
                    
                </table>
            </div>
    </div>


    <?php echo $__env->make('multas.layouts.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('multas.layouts.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('multas.layouts.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('multas.layouts.editar_referencia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('multas.layouts.ver_asignados', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
    
    function EditarMR(id,motivo,monto,tipo,observacion) {

        $('#id_edit').val(id);
        $('#motivo_e').val(motivo);
        $('#monto_e').val(monto);
        $('#observacion_e').val(observacion);
        $("#tipo_edit").val(tipo);
        $("#mensajeEditar").val(tipo);
    }

    function eliminar(id) {
        $('#id_delete').val(id);
    }
    function verAsignados(id_multa){
        $('#CargandoAsignadosComprobar').css('display','block');
        $('#ver_multas_asignadas').empty();
        $('#verAsignadosMulta').modal('show');
        
        $.get('mr/'+id_multa+'/asignados', function(data) {
        })
        .done(function(data) {
                if(data.length>0){
                    for (var i = 0; i < data.length; i++) {
                        if(data[i].status == 'Pagada'){
                            $('#ver_multas_asignadas').append(
                                '<tr>'+
                                    '<td align="center"><center>'+data[i].nombres+' '+data[i].apellidos+'</center></td>'+
                                    '<td align="center"><center>'+data[i].rut+'</center></td>'+
                                    '<td align="center" class="text-success"><center>'+data[i].status+'</center></td>'+
                                '</tr>'
                            );
                        }else if(data[i].status == 'Por Confirmar'){
                            $('#ver_multas_asignadas').append(
                                '<tr>'+
                                    '<td align="center"><center>'+data[i].nombres+' '+data[i].apellidos+'</center></td>'+
                                    '<td align="center"><center>'+data[i].rut+'</center></td>'+
                                    '<td align="center" class="text-success"><center>'+
                                        '<div class="text-warning"><strong>' +data[i].status+'</strong> | CÓDIGO TRANS.: <b>'+data[i].referencia+'</b></div>'+'</center>'+
                                    '</td>'+
                                '</tr>'
                            );
                        }else{
                            $('#ver_multas_asignadas').append(
                                '<tr>'+
                                    '<td align="center"><center>'+data[i].nombres+' '+data[i].apellidos+'</center></td>'+
                                    '<td align="center"><center>'+data[i].rut+'</center></td>'+
                                    '<td align="center" class="text-info"><center>'+data[i].status+'</center></td>'+
                                '</tr>'
                            );
                        }
                        // $.get('mr/'+data[i].id+'/asignados2',function (data2) {
                        // })
                        // .done(function(data2) {
                        //     if(data2[i].status == 'Por Confirmar'){
                        //         $('#ver_multas_asignadas').append(
                        //             '<p class="text-warning"><strong>' +data2[i].status+'</strong> | CÓDIGO TRANS.: <b>'+data2[i].referencia+'</b></p>'
                        //         );
                        //     }else{
                        //         $('#ver_multas_asignadas').append(
                        //             '<center><label>'+data[i].rut+'</label></center>'+
                        //         );
                        //     }
                        // });
                    }
                }else{
                    $('#ver_multas_asignadas').append(
                                '<tr>'+
                                    '<td align="center" colspan="3"><center>No se encuentra asiganda a ningún residente</center></td>'+
                                '</tr>'
                            );
                }
        });
        $('#CargandoAsignadosComprobar').css('display','none');
    }

    function editarReferencia(id_multa, id_pivot) {
        $('#editarReferencia').modal('show');
        $('#codigoActualRef').empty();
        $('#id_pivot').val(id_pivot);

        $.get('mr/'+id_multa+'/asignados', function(data) {
        })
        .done(function(data) {
            if(data.length>0){
                for (var i = 0; i < data.length; i++) {
                    alert(data[i].refer);
                    if(data[i].id_pivot == id_pivot){
                        $('#codigoActualRef').append(
                            '<center>'+
                                '<div class="row">'+
                                    '<div class="col-md-12">'+
                                        '<div class="form-group">'+
                                            '<label for="">Código de Trans. Actual</label>'+
                                            '<h3 align="center" class="text-warning">'+data[i].refer+'</h3>'+
                                        '</div>'+
                                    '</div>'+
                                '</div>'+
                            '</center>'
                        );
                    }
                }
            }else{
                alert('no hay');
            }
        });
    }
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\controlapp4.0\resources\views/multas/index.blade.php ENDPATH**/ ?>
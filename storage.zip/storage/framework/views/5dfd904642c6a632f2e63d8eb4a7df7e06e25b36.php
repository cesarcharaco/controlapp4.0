<!DOCTYPE html>
<html>
<head>
	<title>Reporte Específico</title>
	<style type="text/css">

		body {
			/*background-image: url('../../public/assets/images/fondos.png');
			background-repeat: no-repeat;
			background-attachment: fixed;*/

		  	font-family: 'helvetica neue', helvetica, arial, sans-serif;
		}

		table {
			table-layout: fixed;
			width: 100%;
			border-collapse: collapse;
			border: 3px solid grey;
  			border-radius: 1em;
  			overflow: hidden;
		}

		thead th:nth-child(1) {
		  width: 30%;
		}

		thead th:nth-child(2) {
		  width: 20%;
		}

		thead th:nth-child(3) {
		  width: 15%;
		}

		thead th:nth-child(4) {
		  width: 35%;
		}

		th, td {
		  padding: 20px;
		}

		/* --------------------------------------------------- */

		thead th, tfoot th {
		  font-family: 'Rock Salt', cursive;
		}

		th {
		  /*letter-spacing: 2px;*/
		}

		td {
		  letter-spacing: 1px;
		}

		tbody td {
		  text-align: center;
		}

		tfoot th {
		  text-align: right;
		}


		/* --------------------------------------------------------- */

		thead, tfoot {
		  color: white;
		  text-shadow: 1px 1px 1px black;
		}

		thead th, tfoot th, tfoot td {
		  background: linear-gradient(to bottom, rgba(0,0,0,0.1), rgba(0,0,0,0.5));
		  border: 3px solid blue;
		}


		/* --------------------------------------------------------- */
		tbody tr:nth-child(odd) {
		  background-color: white;
		}

		tbody tr:nth-child(even) {
		  background-color: #D5D7D8;
		}

		table {
		  background-color: #D5D7D8;
		}
	</style>
</head>
<body>
<?php if(!is_null($residentes)): ?>
	<?php for($ra=0;$ra< count($aniosResidentes) ; $ra++): ?>
	<div style="float: left">
		<table style="width: 500px !important;">
			<tbody>
				<tr>
					<th>Año</th>
				</tr>
				<tr>
					<td><?php echo e($aniosResidentes[$ra]); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div style="text-align: right">
		<center><img width="300" height="300" style="border-radius: 50px;" src="../public/assets/images/logo.jpg"></center>
	</div>
	<table width="100%" border="1">
		<!-- <tr><th colspan="6">RESIDENTES</th></tr> -->
		<?php for($i=0; $i < count($mesesResidentes); $i++): ?>	
		<tr>
			<th colspan="6" align="center"><div align="float-right">MES:<?php echo e(meses($mesesResidentes[$i])); ?></div></th>
		</tr>
			<?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<th>Inmueble(s)</th>
				<th>Nombre residente</th>
				<th>Rut/Clave</th>
				<th colspan="2">Correo</th>
				<th>Teléfono de contacto</th>
			</tr>
			<tr>
				<td><?php echo e(inmuebles_asig($key->id)); ?></td>
				<td><?php echo e($key->apellidos); ?>, <?php echo e($key->nombres); ?></td>
				<td><?php echo e($key->rut); ?></td>
				<td colspan="2"><?php echo e($key->email); ?></td>
				<td><?php echo e($key->telefono); ?></td>
			</tr>
			<tr>
				<th>Estacionamiento(s)</th>
				<th>Monto gasto común</th>
				<th>Estado de pago de gasto común</th>
				<th>Monto de Recarga</th>
				<th>Estado de pago de recarga</th>
				<th>Detalle de recarga</th>
			</tr>
			<tr>
				<td><?php echo e(estacionamientos_asig($key->id)); ?></td>
				<td><?php echo e(gasto_comun_mes($mesesResidentes[$i],$key->id,$aniosResidentes[$ra])); ?></td>
				<td> 
					<?php echo e(status_gastos_i($mesesResidentes[$i],$key->id,$aniosResidentes[$ra])); ?>

					<br>
					<?php echo e(status_gastos_e($mesesResidentes[$i],$key->id,$aniosResidentes[$ra])); ?>

				</td>
				<td><?php echo e(montos_mr($mesesResidentes[$i],$key->id,$aniosResidentes[$ra])); ?></td>
				<td><?php echo e(status_montos_mr($mesesResidentes[$i],$key->id,$aniosResidentes[$ra])); ?></td>
				<td></td>
			</tr>
			<tr>
				<td colspan="6" style="background-color: gray;"><div class="page-break"></div></td>
			</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<!-- <tr>
				<td colspan="6" style="background-color: blue;"><br></td>
			</tr> -->
		<?php endfor; ?>
		<tr>
			<td colspan="6" style="background-color: blue;"><br></td>
		</tr>
	</table>
	<?php endfor; ?>
<?php endif; ?>
<?php if(!is_null($inmuebles)): ?>
<hr><br>
<?php for($ia=0;$ia<count($aniosInmuebles);$ia++): ?>
	<div style="float: left">
		<table style="width: 500px !important;">
			<tbody>
				<tr>
					<th>Año</th>
				</tr>
				<tr>
					<td><?php echo e($aniosInmuebles[$ia]); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div style="text-align: right">
		<center><img width="300" height="300" style="border-radius: 50px;" src="../public/assets/images/logo.jpg"></center>
	</div>
<table width="100%" border="1">
	<tbody>
		<tr>
			<th>INMUEBLES</th>
		</tr>
		<?php for($i=0; $i < count($mesesInmuebles); $i++): ?>
			<tr>
				<th colspan="6">Mes: <?php echo e(meses($mesesInmuebles[$i])); ?></th>
			</tr>
		<tr>
			<th>IDEM</th>
			<th>TIPO</th>
			<th>DISPONIBLIDAD</th>
			<th>ESTACIONAMIENTO</th>
			<th>CUANTOS</th>
			<th>ESTADO DE ALQUILER</th>
		</tr>
			<?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($key->idem); ?></td>
				<td><?php echo e($key->tipo); ?></td>
				<td><?php echo e($key->status); ?></td>
				<td><?php echo e($key->estacionamiento); ?></td>
				<td><?php echo e($key->cuantos); ?></td>
				<td><?php echo e(alquiler_i($mesesInmuebles[$i],$key->id,$aniosInmuebles[$ia])); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endfor; ?>
		<tr>
			<td colspan="6" style="background-color: green;"><br></td>
		</tr>
	</tbody>
</table>
	<?php endfor; ?>
<?php endif; ?>
<?php if(!is_null($estacionamientos)): ?>
<hr><br>
<?php for($ea=0;$ea<count($aniosEstaciona);$ea++): ?>
	<div style="float: left">
		<table style="width: 500px !important;">
			<tbody>
				<tr>
					<th>Año</th>
				</tr>
				<tr>
					<td><?php echo e($aniosEstaciona[$ea]); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div style="text-align: right">
		<center><img width="300" height="300" style="border-radius: 50px;" src="../public/assets/images/logo.jpg"></center>
	</div>
<table width="100%" border="1">
	<tbody>
		<tr>
			<th colspan="3">ESTACIONAMIENTOS</th>
		</tr>
		<?php for($i=0; $i < count($mesesEstaciona); $i++): ?>
			<tr>
				<th>Año: <?php echo e($aniosEstaciona[$ea]); ?> </th>
				<th >Mes: <?php echo e(meses($mesesEstaciona[$i])); ?></th>
				<th></th>
			</tr>
		<tr>
			<th>IDEM</th>
			<th>STATUS</th>
			<th>ESTADO DE ALQUILER</th>
		</tr>
			<?php $__currentLoopData = $estacionamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($key->idem); ?></td>
				<td><?php echo e($key->status); ?></td>
				<td><?php echo e(alquiler_e($mesesEstaciona[$i],$key->id,$aniosEstaciona[$ea])); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endfor; ?>
		<tr>
			<td colspan="6" style="background-color: green;"><br></td>
		</tr>
	</tbody>
</table>
	<?php endfor; ?>
<?php endif; ?>
<?php if(!is_null($mr)): ?>
<hr><br>
	<?php for($ea=0;$ea < count($aniosMultas);$ea++): ?>
		<div style="float: left">
			<table style="width: 500px !important;">
				<tbody>
					<tr>
						<th>Año</th>
					</tr>
					<tr>
						<td><?php echo e($aniosMultas[$ea]); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div style="text-align: right">
			<center><img width="300" height="300" style="border-radius: 50px;" src="../public/assets/images/logo.jpg"></center>
		</div>
		<table width="100%" border="1">
			<tbody>
				<tr>
					<th colspan="4">MULTAS-RECARGAS</th>
				</tr>
				<?php for($i=0; $i < count($mesesMultas); $i++): ?>
					<tr>
						<th>Año: <?php echo e($aniosMultas[$ea]); ?> </th>
						<th >Mes: <?php echo e(meses($mesesMultas[$i])); ?></th>
						<th></th>
					</tr>
				<tr>
					<th>MOTIVO</th>
					<th>OBSERVACIÓN</th>
					<th>MONTO</th>
					<TH>TIPO</TH>
				</tr>
					<?php $__currentLoopData = $mr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($key->motivo); ?></td>
						<td><?php echo e($key->observacion); ?></td>
						<td><?php echo e($key->monto); ?></td>
						<td style="border-top-color: black;"><?php echo e($key->tipo); ?></td>
						
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endfor; ?>
				<tr>
					<td colspan="6" style="background-color: green;"><br></td>
				</tr>
			</tbody>
		</table>
	<?php endfor; ?>
<?php endif; ?>
<?php if(!is_null($residentes) && !is_null($inmuebles) && !is_null($estacionamientos)): ?>
<center><h1></h1></center>
<?php endif; ?>
</body>
</html><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/reportes/PDF/ReporteEspecifico.blade.php ENDPATH**/ ?>
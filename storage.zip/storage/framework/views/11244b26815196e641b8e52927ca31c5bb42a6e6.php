<div class="vistaColumnaMembresia EliminarMembresia border border-danger shadow" id="EliminarMembresia" style="display: none; border-radius: 30px !important;">
	<?php echo Form::open(['route' => ['membresias.destroy',1033], 'method' => 'DELETE']); ?>

		<?php echo csrf_field(); ?>
		<div class="card-body">
		
			<h3>¿Está realmente seguro de querer eliminar esta membresía?</h3> 
			Se eliminarán todos los pagos y datos relacionadas a esta membresía.
			<center>
				<input type="hidden" name="id_membresia" id="id_membresia">
				<button type="submit" class="btn btn-danger">Eliminar</button>
			</center>
		</div>
	<?php echo Form::close(); ?>

</div><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/membresias/layouts/delete.blade.php ENDPATH**/ ?>
<?php echo Form::open(['route' => ['multas_recargas.destroy',1033],'method' => 'DELETE', 'name' => 'EliminarMulta', 'id' => 'eliminar_multa', 'data-parsley-validate']); ?>

    <?php echo csrf_field(); ?>
    <div class="modal fade" id="eliminarMulta" role="dialog">
        <div class="modal-dialog modals-default">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Eliminar Multa</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h2>¡Atención!</h2>
                    <h4>¿Está realmente seguro de querer eliminar este Multa?</h4>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="id_mr" id="id_delete">
                    <button type="submit" class="btn btn-success" >Eliminar</button>
                </div>
            </div>
        </div>
    </div>
<?php echo Form::close(); ?><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/multas/layouts/delete.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Reportes</h1>
            </div>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(count($errors)): ?>
            <div class="alert-list m-4">
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($error); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        <?php endif; ?>
        <div class="card border border-danger rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="display: none;">
        	<h3 align="center">Reporte General</h3>
        	<div class="card-body">



        		<form action="<?php echo e(route('reportes.general')); ?>" target="_blank" method="POST" accept-charset="utf-8">
			   	<?php echo csrf_field(); ?>

	        		<div class="row">
	        			<div class="col-md-4">
			        		<div class="form-group">
			        			<label class="text-primary">Meses</label>
			        			<select class="form-control select2 border border-default" multiple name="id_mes[]">
			        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
			        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			        			</select>
			        		</div>
	        			</div>

	        			<div class="col-md-4">
			        		<div class="form-group">
			        			<label class="text-primary">Año</label>
			        			<select class="form-control select2 border border-default" name="anio">
			        				<?php for($j=0;$j< count($anio);$j++): ?>
			        					<option value="<?php echo e($anio[$j]); ?>"><?php echo e($anio[$j]); ?></option>
			        				<?php endfor; ?>
			        			</select>
			        		</div>
	        			</div>

	        			<div class="col-md-2"><br>
	        				<h3><button type="submit" class="btn btn-danger btn-rounded">Generar PDF</button></h3>
	        			</div>
	        		</div>

	        	</form>
        	</div>
        </div>

				        
        <?php if(\Auth::user()->tipo_usuario == 'Admin'): ?>
	        <div class="card border border-danger rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="display: none;">
	    			<h3 align="center">Reporte</h3>
	            <div class="card-body">
	                <div class="row justify-content-center">
			            <!-- <div class="col-md-12">
			                <div class="row">
			                    <div class="col-md-12 offset-md-9">
			                        <a class="btn btn-success" data-toggle="modal" data-target="#crearMensualidad" style="border-radius: 30px; color: white;">
			                            <span> Reportes </span>
			                        </a>
			                    </div>
			                </div>
			            </div> -->                    

			        </div>

				    	

				    <form action="<?php echo e(route('reportes.store')); ?>" target="_blank" method="POST" accept-charset="utf-8">
				   	<?php echo csrf_field(); ?>

				    	





					        <div class="row justify-content-center">
					        	<div class="col-md-6">
				        			<div class="card border border-primary rounded shadow">
				        				<div class="card-body">
							        		<div class="form-group">
							        			<label class="text-primary">Inmuebles</label>
							        			<select multiple name="id_inmuebles[]" id="selectTodosInmuebles">
							        				<?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->idem); ?></option>
							        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        			</select>
							        			<div style="display: none">
								        			<select multiple id="selectTodosInmuebles2" style="display: none;">
								        				<?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->idem); ?></option>
								        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								        			</select>
							        				
							        			</div>
							        		</div>
							        		<div class="form-group">
							        			<label>¿Todos los inmuebles?</label>
							        			<input type="checkbox" value="Si" name="InmueblesTodos" id="InmueblesTodos" onchange="TodosInmuebles()">
							        		</div>

				        					<div class="row justify-content-center">
					        					<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="meses_inmuebles[]" id="selectMesesInmuebles">
									        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
									        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="meses_inmuebles[]" id="selectMesesInmuebles2" style="display: none;">
										        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
										        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los meses del año?</label>
									        			<input type="checkbox" value="MesesTodosInmuebles" name="MesesTodosInmuebles" id="MesesTodosInmuebles" onchange="TodosMesesInmuebles()">
									        		</div>
									        	</div>
									        	<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="anios_inmueble[]" id="selectTodosAniosInmuebles">
									        				<?php for($i=0; $i< count($anio); $i++): ?>
									        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
									        				<?php endfor; ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="anios_inmueble[]" id="selectTodosAniosInmuebles2" style="display: none">
										        				<?php for($i=0; $i< count($anio); $i++): ?>
										        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
										        				<?php endfor; ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los años?</label>
									        			<input type="checkbox" value="AniosTodosInmuebles" name="AniosTodosInmuebles" id="AniosTodosInmuebles" onchange="TodosAniosInmuebles()">
									        		</div>
									        	</div>
									        </div>
				        				</div>
				        			</div>
					        	</div>

					        	<div class="col-md-6">
					        		<div class="card border border-warning rounded shadow">
				        				<div class="card-body">
							        		<div class="form-group">
							        			<label class="text-warning">Estacionamientos</label>
							        			<select class="form-control select2 border border-warning" multiple name="id_estacionamientos[]" id="selectTodosEstacionamientos">
							        				<?php $__currentLoopData = $estacionamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->idem); ?></option>
							        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        			</select>
							        			<div style="display: none">
							        				<select class="form-control select2 border border-warning" multiple name="id_estacionamientos[]" id="selectTodosEstacionamientos2">
								        				<?php $__currentLoopData = $estacionamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->idem); ?></option>
								        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        				</select>
							        			</div>
							        		</div>
							        		<div class="form-group">
							        			<label>¿Todos los estacionamientos?</label>
							        			<input type="checkbox" value="Si" name="EstacionamientosTodos" id="EstacionamientosTodos" onchange="TodosEstacionamientos()">
							        		</div>

							        		<div class="row justify-content-center">
					        					<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="meses_estaciona[]" id="selectMesesEstaciona">
									        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
									        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="meses_estaciona[]" id="selectMesesEstaciona2" style="display: none;">
										        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
										        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los meses del año?</label>
									        			<input type="checkbox" value="MesesTodosEstaciona" name="MesesTodosEstaciona" id="MesesTodosEstaciona" onchange="TodosMesesEstaciona()">
									        		</div>
									        	</div>
									        	<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="anios_estaciona[]" id="selectAniosEstaciona">
									        				<?php for($i=0; $i< count($anio); $i++): ?>
									        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
									        				<?php endfor; ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="anios_estaciona[]" id="selectAniosEstaciona2" style="display: none;">
										        				<?php for($i=0; $i< count($anio); $i++): ?>
										        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
										        				<?php endfor; ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los años?</label>
									        			<input type="checkbox" value="AniosTodosEstaciona" name="AniosTodosEstaciona" id="AniosTodosEstaciona" onchange="TodosAniosEstaciona()">
									        		</div>
									        	</div>
									        </div>
							        	</div>
							        </div>
					        	</div>
					        </div>
					         <div class="row justify-content-center">
					        	<div class="col-md-6">
					        		<div class="card border border-success rounded shadow">
				        				<div class="card-body">
							        		<div class="form-group">
							        			<label class="text-success">Residentes</label>
							        			<select class="form-control select2 border border-success" multiple name="id_residentes[]" id="selectTodosResidentes">
							        				<?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->nombres); ?> <?php echo e($key->apellidos); ?> - <?php echo e($key->rut); ?></option>
							        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        			</select>
							        			<div style="display: none">
							        				<select class="form-control select2 border border-success" multiple name="id_residentes[]" id="selectTodosResidentes2">
							        				<?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->nombres); ?> <?php echo e($key->apellidos); ?> - <?php echo e($key->rut); ?></option>
							        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        			</select>
							        			</div>
							        		</div>
							        		<div class="form-group">
							        			<label>¿Todos los residentes?</label>
							        			<input type="checkbox" value="Si" name="ResidentesTodos" id="ResidentesTodos" onchange="TodosResidentes()">
							        		</div>
									        <div class="row justify-content-center">
					        					<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="meses_residentes[]" id="selectMesesResidentes">
									        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
									        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="meses_residentes[]" id="selectMesesResidentes2" style="display: none">
										        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
										        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los meses del año?</label>
									        			<input type="checkbox" value="MesesTodosResidentes" name="MesesTodosResidentes" id="MesesTodosResidentes" onchange="TodosMesesResidentes()">
									        		</div>
									        	</div>
									        	<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="anios_residentes[]" id="selectAniosResidentes">
									        				<?php for($i=0; $i< count($anio); $i++): ?>
									        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
									        				<?php endfor; ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="anios_residentes[]" id="selectAniosResidentes2" style="display: none">
										        				<?php for($i=0; $i< count($anio); $i++): ?>
										        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
										        				<?php endfor; ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los años?</label>
									        			<input type="checkbox" value="AniosTodosResidentes" name="AniosTodosResidentes" id="AniosTodosResidentes" onchange="TodosAniosResidentes()">
									        		</div>
									        	</div>
									        </div>
							        	</div>
							        </div>
					        	</div>

					        	<div class="col-md-6">
					        		<div class="card border border-danger rounded shadow">
				        				<div class="card-body">
							        		<div class="form-group">
							        			<label class="text-danger">Multas - Recargas</label>
							        			<select class="form-control select2 border border-success" multiple name="id_multa[]" id="selectTodosMultas">
							        				<?php $__currentLoopData = $multas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->motivo); ?> <?php echo e($key->tipo); ?> - <?php echo e($key->monto); ?></option>
							        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        			</select>
							        			<div style="display: none">
							        				<select class="form-control select2 border border-success" multiple name="id_multa[]" id="selectTodosMultas2">
							        				<?php $__currentLoopData = $multas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->motivo); ?> <?php echo e($key->tipo); ?> - <?php echo e($key->monto); ?></option>
							        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							        			</select>
							        			</div>
							        		</div>
							        		<div class="form-group">
									        	<label>¿Todas las Multas y recargas? </label>
									        	<input type="checkbox" value="Si" name="MultasRecargas" id="MultasTodas" onclick="TodosMultas()">
									        </div>
									        <div class="row justify-content-center">
					        					<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="meses_multas[]" id="selectMesesMultas">
									        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
									        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="meses_multas[]" id="selectMesesMultas2" style="display: none">
										        				<?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										        					<option value="<?php echo e($key->id); ?>"><?php echo e($key->mes); ?></option>
										        				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los meses del año?</label>
									        			<input type="checkbox" value="MesesTodosMultas" name="MesesTodosMultas" id="MesesTodosMultas" onchange="TodosMesesMultas()">
									        		</div>
									        	</div>
									        	<div class="col-md-6">
									        		<div class="form-group">
									        			<select class="form-control select2 border border-default" multiple name="anios_multas[]" id="selectAniosMultas">
									        				<?php for($i=0; $i< count($anio); $i++): ?>
									        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
									        				<?php endfor; ?>
									        			</select>
									        			<div style="display: none">
										        			<select class="form-control select2 border border-default" multiple name="anios_multas[]" id="selectAniosMultas2" style="display: none">
										        				<?php for($i=0; $i< count($anio); $i++): ?>
										        					<option value="<?php echo e($anio[$i]); ?>"><?php echo e($anio[$i]); ?></option>
										        				<?php endfor; ?>
										        			</select>
										        		</div>
									        		</div>
									        		<div class="form-group">
									        			<label>¿Todos los años?</label>
									        			<input type="checkbox" value="AniosTodosMultas" name="AniosTodosMultas" id="AniosTodosMultas" onchange="TodosAniosMultas()">
									        		</div>
									        	</div>
									        </div>
							        	</div>
							        </div>
					        	</div>
					        </div>


			        	<!-- <div class="card border border-warning rounded"> -->
				        	<!-- <div class="card-body"> -->
						        
						    <!-- </div> -->
						<!-- </div> -->


					        <!-- <div class="float-right">
					        	<h3><button type="button" class="btn btn-danger btn-rounded">Generar PDF</button></h3>
					        </div> -->

				        
					        <div class="float-right">
					        	<h3><button type="submit" class="btn btn-danger btn-rounded">Generar PDF</button></h3>
					        </div>

				    </form>

			    </div>
			</div>
		<?php endif; ?>

    

<?php $__env->stopSection(); ?>

<script type="text/javascript">

</script>
<script type="text/javascript">

    function Eliminar(id) {
        $('#id').val(id);
    }


    // -----------------------------INMUEBLES --------------------------------------
    function TodosInmuebles() {
    	if($('#InmueblesTodos').prop('checked')){
    		$('#selectTodosInmuebles').attr('disabled',true);
    		var options = $("#selectTodosInmuebles2 > option").clone();
    		$("#selectTodosInmuebles > option").remove();
    		$("#selectTodosInmuebles").append(options);

    		// $("#selectTodosInmuebles").multiselect("clearSelection");
			// $("#selectTodosInmuebles").multiselect( 'refresh' );
    	}else{
    		$('#selectTodosInmuebles').removeAttr('disabled',false);
    	}
    }

    function TodosMesesInmuebles() {
    	if($('#MesesTodosInmuebles').prop('checked')){
    		$('#selectMesesInmuebles').attr('disabled',true);
    		var options = $("#selectMesesInmuebles2 > option").clone();
    		$("#selectMesesInmuebles > option").remove();
    		$("#selectMesesInmuebles").append(options);
    	}else{
    		$('#selectMesesInmuebles').removeAttr('disabled',false);
    	}
    }

    function TodosAniosInmuebles() {
    	if($('#AniosTodosInmuebles').prop('checked')){
    		$('#selectTodosAniosInmuebles').attr('disabled',true);
    		var options = $("#selectTodosAniosInmuebles2 > option").clone();
    		$("#selectTodosAniosInmuebles > option").remove();
    		$("#selectTodosAniosInmuebles").append(options);
    	}else{
    		$('#selectTodosAniosInmuebles').removeAttr('disabled',false);
    	}
    }

    //-------------------------------ESTACIONAMIENTOS-------------------------------

    function TodosEstacionamientos() {
    	if($('#EstacionamientosTodos').prop('checked')){
    		$('#selectTodosEstacionamientos').attr('disabled',true);
    		var options = $("#selectTodosEstacionamientos2 > option").clone();
    		$("#selectTodosEstacionamientos > option").remove();
    		$("#selectTodosEstacionamientos").append(options);
    	}else{
    		$('#selectTodosEstacionamientos').removeAttr('disabled',false);
    	}
    }
    function TodosMesesEstaciona() {
    	if($('#MesesTodosEstaciona').prop('checked')){
    		$('#selectMesesEstaciona').attr('disabled',true);
    		var options = $("#selectMesesEstaciona2 > option").clone();
    		$("#selectMesesEstaciona > option").remove();
    		$("#selectMesesEstaciona").append(options);
    	}else{
    		$('#selectMesesEstaciona').removeAttr('disabled',false);
    	}
    }

    function TodosAniosEstaciona() {
    	if($('#AniosTodosEstaciona').prop('checked')){
    		$('#selectAniosEstaciona').attr('disabled',true);
    		var options = $("#selectAniosEstaciona2 > option").clone();
    		$("#selectAniosEstaciona > option").remove();
    		$("#selectAniosEstaciona").append(options);
    	}else{
    		$('#selectAniosEstaciona').removeAttr('disabled',false);
    	}
    }

    //-------------------------------------residentes------------------------------
    function TodosResidentes() {
    	if($('#ResidentesTodos').prop('checked')){
    		$('#selectTodosResidentes').attr('disabled',true);
    		var options = $("#selectTodosResidentes2 > option").clone();
    		$("#selectTodosResidentes > option").remove();
    		$("#selectTodosResidentes").append(options);
    	}else{
    		$('#selectTodosResidentes').removeAttr('disabled',false);
    	}
    }

    function TodosMesesResidentes() {
    	if($('#MesesTodosResidentes').prop('checked')){
    		$('#selectMesesResidentes').attr('disabled',true);
    		var options = $("#selectMesesResidentes2 > option").clone();
    		$("#selectMesesResidentes > option").remove();
    		$("#selectMesesResidentes").append(options);
    	}else{
    		$('#selectMesesResidentes').removeAttr('disabled',false);
    	}
    }

    function TodosAniosResidentes() {
    	if($('#AniosTodosResidentes').prop('checked')){
    		$('#selectAniosResidentes').attr('disabled',true);
    		var options = $("#selectAniosResidentes2 > option").clone();
    		$("#selectAniosResidentes > option").remove();
    		$("#selectAniosResidentes").append(options);
    	}else{
    		$('#selectAniosResidentes').removeAttr('disabled',false);
    	}
    }

    //-------------------------------------MULTAS------------------------------
    function TodosMultas() {
    	if($('#MultasTodas').prop('checked')){
    		$('#selectTodosMultas').attr('disabled',true);
    		var options = $("#selectTodosMultas2 > option").clone();
    		$("#selectTodosMultas > option").remove();
    		$("#selectTodosMultas").append(options);
    	}else{
    		$('#selectTodosMultas').removeAttr('disabled',false);
    	}
    }

    function TodosMesesMultas() {
    	if($('#MesesTodosMultas').prop('checked')){
    		$('#selectMesesMultas').attr('disabled',true);
    		var options = $("#selectMesesMultas2 > option").clone();
    		$("#selectMesesMultas > option").remove();
    		$("#selectMesesMultas").append(options);
    	}else{
    		$('#selectMesesMultas').removeAttr('disabled',false);
    	}
    }

    function TodosAniosMultas() {
    	if($('#AniosTodosMultas').prop('checked')){
    		$('#selectAniosMultas').attr('disabled',true);
    		var options = $("#selectAniosMultas2 > option").clone();
    		$("#selectAniosMultas > option").remove();
    		$("#selectAniosMultas").append(options);
    	}else{
    		$('#selectAniosMultas').removeAttr('disabled',false);
    	}
    }

    
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/reportes/index.blade.php ENDPATH**/ ?>
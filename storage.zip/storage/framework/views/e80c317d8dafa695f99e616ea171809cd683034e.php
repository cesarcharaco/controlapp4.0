<?php
  libxml_use_internal_errors(true);
  
?>
<!DOCTYPE html>
<html>
<head>
	<title>Reporte General</title>
	<style type="text/css">

		body {
			/*background-image: url('../../public/assets/images/fondos.png');
			background-repeat: no-repeat;
			background-attachment: fixed;*/

		  	font-family: 'helvetica neue', helvetica, arial, sans-serif;
		}

		table {
			table-layout: fixed;
			width: 100%;
			border-collapse: collapse;
			border: 3px solid grey;
  			border-radius: 1em;
  			overflow: hidden;
		}

		thead th:nth-child(1) {
		  width: 30%;
		}

		thead th:nth-child(2) {
		  width: 20%;
		}

		thead th:nth-child(3) {
		  width: 15%;
		}

		thead th:nth-child(4) {
		  width: 35%;
		}

		th, td {
		  padding: 20px;
		}

		/* --------------------------------------------------- */

		thead th, tfoot th {
		  font-family: 'Rock Salt', cursive;
		}

		th {
		  /*letter-spacing: 2px;*/
		}

		td {
		  letter-spacing: 1px;
		}

		tbody td {
		  text-align: center;
		}

		tfoot th {
		  text-align: right;
		}


		/* --------------------------------------------------------- */

		thead, tfoot {
		  color: white;
		  text-shadow: 1px 1px 1px black;
		}

		thead th, tfoot th, tfoot td {
		  background: linear-gradient(to bottom, rgba(0,0,0,0.1), rgba(0,0,0,0.5));
		  border: 3px solid blue;
		}


		/* --------------------------------------------------------- */
		tbody tr:nth-child(odd) {
		  background-color: white;
		}

		tbody tr:nth-child(even) {
		  background-color: #D5D7D8;
		}

		table {
		  background-color: #D5D7D8;
		}
	</style>
</head>
<body>

	<div style="float: left">
		<table style="width: 500px !important;">
			<tbody>
				<tr>
					<th>Año</th>
				</tr>
				<tr>
					<td><?php echo e($anio); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<div style="text-align: right">
		<center><img width="300" height="300" style="border-radius: 50px;" src="../public/assets/images/logo.jpg"></center>
	</div>
	<!-- <p> Formato PDF para explicar la gestión y datos que se han almacenado hasta ahora</p> -->
	<table width="100%" border="1">
		
		<tbody>
			<?php for($i=0; $i < count($meses); $i++): ?>
				<tr>
					<th colspan="6">Mes: <?php echo e(meses($meses[$i])); ?></th>
				</tr>
				<?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<th>Inmueble(s)</th>
						<th>Nombre residente</th>
						<th>Rut/Clave</th>
						<th colspan="2">Correo</th>
						<th>Teléfono de contacto</th>
					</tr>
					<tr>
						<td><?php echo e(inmuebles_asig($key->id)); ?></td>
						<td><?php echo e($key->apellidos); ?>, <?php echo e($key->nombres); ?></td>
						<td><?php echo e($key->rut); ?></td>
						<td colspan="2"><?php echo e($key->usuario->email); ?></td>
						<td><?php echo e($key->telefono); ?></td>
					</tr>
					<tr>
						<th>Estacionamiento(s)</th>
						<th>Monto gasto común</th>
						<th>Estado de pago de gasto común</th>
						<th>Monto de Recarga</th>
						<th>Estado de pago de recarga</th>
						<th>Detalle de recarga</th>
					</tr>
					<tr>
						<td><?php echo e(estacionamientos_asig($key->id)); ?></td>
						<td><?php echo e(gasto_comun_mes($meses[$i],$key->id,$anio)); ?></td>
						<td> 
							<?php echo e(status_gastos_i($meses[$i],$key->id,$anio)); ?>

							<br>
							<?php echo e(status_gastos_e($meses[$i],$key->id,$anio)); ?>

						</td>
						<td><?php echo e(montos_mr($meses[$i],$key->id,$anio)); ?></td>
						<td><?php echo e(status_montos_mr($meses[$i],$key->id,$anio)); ?></td>
						<td></td>
					</tr>
					

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td colspan="6" style="background-color: gray;"><br></td>
				</tr>
				
			<?php endfor; ?>
		</tbody>
	</table>

</body>
</html><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/reportes/PDF/ReporteGeneral.blade.php ENDPATH**/ ?>
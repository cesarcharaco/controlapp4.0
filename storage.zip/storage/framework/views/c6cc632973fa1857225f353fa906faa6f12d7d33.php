<div class="collapse multi-collapse" id="editarArriendo2" style=" margin-left: -8px; width: 100% !important; background-color: white !important; border-radius: 30px !important;">
  <div class="card">
    <div class="card-header" style="background-color: white !important;">
        <a data-toggle="collapse" data-target="#editarArriendo2" aria-expanded="false" aria-controls="editarArriendo2" class="btn btn-primary btn-sm text-uppercase float-right text-white" style="border-radius: 5px; float: right;" onclick="cerrar(3)">
          <strong>Cerrar</strong>
        </a>
      </div>
    <div class="border card-body">
      <h4>Editar Arriendo <br> <small>Todos los campos (<b style="color: red;">*</b>) son requerido.</small></h4>
      <?php echo Form::open(['route' => ['editar_alquiler'], 'enctype' => 'multipart/form-data', 'method' => 'POST', 'name' => 'update_arriendo', 'id' => 'update_arriendo', 'data-parsley-validate']); ?>

        <?php echo csrf_field(); ?>
        <ul class="nav nav-pills nav-fill mb-3" id="pills-tab" role="tablist" style="background-color: #C5C5C5 !important;">
          <li class="nav-item">
            <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-homeE" role="tab" aria-controls="pills-empresaE" aria-selected="true">1</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-pagoE" role="tab" aria-controls="pills-datosE" aria-selected="false">2</a>
          </li>
        </ul>
        <div class="tab-content" id="pills-tabContent">
            <div class="tab-pane fade show active" id="pills-homeE" role="tabpanel" aria-labelledby="pills-home-tab">
                <center>
                  <div class="form-group">
                    <label>Residente <b class="text-danger">*</b></label>
                    <select class="form-control select2" id="id_residenteArriendoE" onchange="buscarTodo(this.value)" name="id_residente" required>
                        <option disabled>Seleccione residente</option>
                        <?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->nombres); ?> <?php echo e($key->apellidos); ?> - <?php echo e($key->rut); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                   <div class="form-group">
                    <label>Instalación <b class="text-danger">*</b></label>
                    <select class="form-control select2" id="instalacionListArriendoE" name="id_instalacion">
                        <option disabled required>Seleccione instalación</option>
                        <?php $__currentLoopData = $instalaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key->id); ?>"><?php echo e($key->nombre); ?> - Dias disponible:<?php $__currentLoopData = $key->dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key2->dia); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($key->status); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Tipo de Alquiler</label>
                    <select class="form-control select2" id="tipo_alquilerArriendoE" name="tipo_alquiler" onchange="TipoAlquiler(this.value)" required>
                      <option value="Permanente">Permanente</option>
                      <option value="Temporal">Temporal</option>
                    </select>
                  </div>
                  <div class="form-group card shadow vistaTipoAlquiler" style="border-radius: 30px !important; display: none;">
                    <div class="card-body">
                      <div class="form-group">
                        <label>Fecha</label>
                        <input type="date" name="fecha" class="form-control" id="fechaAlquilerArriendoE">
                      </div>
                          
                      <div class="form-group" align="center">
                        <label>Hora</label>
                        <input class="form-control" type="time" name="hora"  id="horaAlquilerArriendoE">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Nro. de horas <b class="text-danger">*</b></label>
                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                      <span class="input-group-addon bootstrap-touchspin-prefix input-group-prepend">
                        <span class="input-group-text" style="width:39px; height:39px;">
                          <i data-feather="watch"></i>
                        </span>
                      </span>
                      <input name="num_horas" min="1" minlength="2" max="24" data-toggle="touchspin" type="number"  class="form-control" placeholder="7" required id="num_horasArriendoE">
                    </div>
                    </div>
                    <div class="form-group">
                      <label>Status</label>
                      <select name="status" class="form-control select2" id="statusArriendoE">
                        <option value="Activo">Activo</option>
                        <option value="Inactivo">Inactivo</option>
                      </select>
                    </div>                                  
                </center>
            </div>
            <div class="tab-pane fade" id="pills-pagoE" role="tabpanel" aria-labelledby="pills-pago-tab">
                <center>
                    <div class="form-group" id="pagoRealizado">
                            <div>                  
                                <label for="admins_todos">¿Se realizó el pago?</label>
                                <input type="checkbox" name="admins_todos" id="pagadoArriendoE"  data-toggle="tooltip" data-placement="top" title="Seleccione si el pago se realizó correctamente" value="1">
                            </div>
                            <div>  
                                <span id="pagadoArriendoE2"></span>
                            </div>
                    </div>
                    <br>
                    <div class="form-group">
                        <label>Referencia <b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="referencia" id="referenciaArriendoE" required maxlength="20">
                    </div>
                    <div class="row">
                        <?php $num=0; ?>
                            <?php $__currentLoopData = $planesPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($num==0): ?>
                                    <div class="col-md-6">
                                        <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                            <div class="card-body">
                                                <div class="custom-control custom-radio mb-2">
                                                  <input type="radio" id="planPArriendoE<?php echo e($key->id); ?>" name="planP" value="<?php echo e($key->id); ?>" checked>
                                                </div>
                                               <h3><?php echo e($key->nombre); ?></h3>
                                               <span><?php echo e($key->dias); ?> dias</span>
                                               <br>
                                                <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                               <br>
                                               <center>
                                                <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                               </center>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-6">
                                        <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                            <div class="card-body">
                                                <div class="custom-control custom-radio mb-2">
                                                  <input type="radio" id="planPArriendoE<?php echo e($key->id); ?>" name="planP" value="<?php echo e($key->id); ?>">
                                                </div>
                                               <h3><?php echo e($key->nombre); ?></h3>
                                               <span><?php echo e($key->dias); ?> dias</span>
                                               <br>
                                                <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                               <br>
                                               <center>
                                                <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                               </center>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php $num++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </center>

            </div>
        </div>
        <div align="center">
            <input type="hidden" name="id" id="id_editarArriendo">
            <button type="submit" class="btn btn-success">Guardar</button>
        </div>
      <?php echo Form::close(); ?>

    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/alquiler/layouts_arriendo/edit.blade.php ENDPATH**/ ?>
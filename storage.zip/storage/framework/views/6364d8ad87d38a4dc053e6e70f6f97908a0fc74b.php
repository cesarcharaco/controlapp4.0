<div class="collapse multi-collapse" id="verAdmin" style=" margin-left: -8px; width: 100% !important; background-color: white !important; border-radius: 30px !important;">
	<div class="card">
		<div class="card-header">
	      <a data-toggle="collapse" data-target="#verAdmin" aria-expanded="false" aria-controls="verAdmin" class="btn btn-primary btn-sm text-uppercase float-right text-white" style="border-radius: 5px; float: right;" onclick="cerrar(4)">
	        <strong>Cerrar</strong>
	      </a>
	    </div>
		<div class="card-body">
			<h4 class="header-title mb-2">Ver Admin</h4>
		</div>
	</div>
</div><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/root/layouts/showAdmin.blade.php ENDPATH**/ ?>
<div class="modal fade" id="VerEstacionamiento" role="dialog">
    <div class="modal-dialog modals-default">
        <div class="modal-content">
            <div class="modal-header">
                <h4>Ver Estacionamiento</h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <center>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Nombre del estacionamiento</label>
                                <span id="ver_idem"></span>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label>Estado del estacionamiento</label>
                                <span id="ver_status"></span>
                            </div>
                        </div>
                    </div>
                </center>
            </div>                            
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/estacionamientos/layouts/show.blade.php ENDPATH**/ ?>
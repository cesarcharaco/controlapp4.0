<link rel="shortcut icon" href="<?php echo e(asset('assets/images/logo.jpg')); ?>">
<link href="<?php echo e(asset('assets/css/login.min.css')); ?>" rel="stylesheet" type="text/css" style="border-radius: 30px;" />
<?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>

    <!-- content -->

    <div class="container-fluid">
        <div class="content row">

            <div class="limiter">
                <div class="container-login100">
                    <div class="wrap-login100">
                        <div class="login100-pic js-tilt" data-tilt>
                            <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" alt="IMG">
                        </div>
                        <div class="logo-mobile">
                            <img src="<?php echo e(asset('assets/images/logo.jpg')); ?>" style="height: 280px;" alt="IMG" class="logo-mobile">
                        </div>

                        <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <span class="login100-form-title">
                                <?php echo e(__('Login')); ?>

                            </span>
                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php if(count($errors)): ?>
                            <div class="alert alert-danger" role="alert">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($error); ?>

                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <div class="wrap-input100 validate-input" data-validate = "Valid email is required: ex@abc.xyz">
                                <input id="email" type="text" class="input100 <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email"
                                value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus
                                placeholder="<?php echo e(__('E-Mail Address')); ?>">
                                <span class="focus-input100"></span>
                                <span class="symbol-input100">
                                    <i class="fa fa-envelope" aria-hidden="true"></i>
                                </span>
                            </div>
                            <div class="alert" style="background-color: #e4eeee;" role="alert" style="border-radius: 30px;">
                                <strong style="font-family: italic;">La contraseña debe tener al menos 9 carácteres.</strong>
                            </div>
                            <div class="wrap-input100 validate-input" data-validate = "Password is required">
                                <input id="password" type="password" class="input100 <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                name="password" required autocomplete="current-password" placeholder="<?php echo e(__('Password')); ?>">
                                <span class="focus-input100"></span>
                                <span class="symbol-input100">
                                    <i class="fa fa-lock" aria-hidden="true"></i>
                                </span>
                            </div>

                            <div class="container-login100-form-btn">
                                <button class="login100-form-btn btn-success" type="submit">
                                    <?php echo e(__('Login')); ?>

                                </button>
                            </div>

                            <div class="text-center p-t-12">
                                <span class="txt1">
                                    <!-- Forgot -->
                                </span>
                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    ControlApp <label class="badge badge-soft-danger">v1.0.1.</label> Un proyecto desarrollado por <a href="https://eiche.cl/" target="_blank" id="eiche">EICHE</a>.
                </div>
            </div>
        </div>
    </footer>
    <?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/auth/login.blade.php ENDPATH**/ ?>
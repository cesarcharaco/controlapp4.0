<div class="collapse multi-collapse" id="nuevoArriendo" style=" margin-left: -8px; width: 100% !important; background-color: white !important; border-radius: 30px !important;">
  <div class="card">
    <div class="card-header" style="background-color: white !important;">
      <a data-toggle="collapse" data-target="#nuevoArriendo" aria-expanded="false" aria-controls="nuevoArriendo" class="btn btn-primary btn-sm text-uppercase float-right text-white" style="border-radius: 5px; float: right;" onclick="cerrar(4)">
        <strong>Cerrar</strong>
      </a>
    </div>  
    <div class="border card-body">
      <h4>Nuevo Arriendo <br> <small>Todos los campos (<b style="color: red;">*</b>) son requerido.</small></h4>

      <?php echo Form::open(['route' => ['registrar_alquiler'], 'enctype' => 'multipart/form-data', 'method' => 'POST', 'name' => 'registrar_alquiler', 'id' => 'registrar_alquiler', 'data-parsley-validate']); ?>

        <?php echo csrf_field(); ?>
          <ul class="nav nav-pills nav-fill mb-3" id="pills-tab" role="tablist" style="background-color: #C5C5C5 !important;">
            <li class="nav-item">
              <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-empresa" aria-selected="true">1</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-pago" role="tab" aria-controls="pills-datos" aria-selected="false">2</a>
            </li>
          </ul>
          <div class="tab-content" id="pills-tabContent" style="width: 100% !important">
            <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                <center>
                  <div class="form-group">
                    <label>Residente <b class="text-danger">*</b></label>
                    <select class="form-control select2" id="id_residente" onchange="buscarTodo(this.value)" name="id_residente" required>
                        <option disabled>Seleccione residente</option>
                        <?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->nombres); ?> <?php echo e($key->apellidos); ?> - <?php echo e($key->rut); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                   <div class="form-group">
                    <label>Instalación <b class="text-danger">*</b></label>
                    <select class="form-control select2" id="instalacionList" name="id_instalacion">
                        <option disabled required>Seleccione instalación</option>
                        <?php $__currentLoopData = $instalaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key->status=="Activo"): ?>
                            <option value="<?php echo e($key->id); ?>"><?php echo e($key->nombre); ?> - Dias disponible:<?php $__currentLoopData = $key->dias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($key2->dia); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> - <?php echo e($key->status); ?></option>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Tipo de Alquiler <b class="text-danger">*</b></label>
                    <select class="form-control select2" id="tipo_alquiler" name="tipo_alquiler" onchange="TipoAlquiler(this.value)" required>
                      <option value="Permanente">Permanente</option>
                      <option value="Temporal">Temporal</option>
                    </select>
                  </div>
                  <div class="form-group card shadow vistaTipoAlquiler" style="border-radius: 30px !important; display: none;">
                    <div class="card-body">
                      <div class="form-group">
                        <label>Fecha</label>
                        <input type="date" max="<?php echo date('Y-m-d');?>" name="fecha" class="form-control" id="fechaAlquiler">
                      </div>
                          
                      <div class="form-group" align="center">
                        <label>Hora</label>
                        <input type="text" id="basic-timepicker" class="form-control flatpickr-input" placeholder="Basic timepicker" readonly="readonly">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Nro. de horas <b class="text-danger">*</b></label>
                    <div class="input-group bootstrap-touchspin bootstrap-touchspin-injected">
                      <span class="input-group-addon bootstrap-touchspin-prefix input-group-prepend">
                        <span class="input-group-text" style="width:39px; height:39px;">
                          <i data-feather="watch"></i>
                        </span>
                      </span>
                      <input name="num_horas" min="1" minlength="2" max="24" data-toggle="touchspin" type="number"  class="form-control" placeholder="7" required>
                    </div>
                    </div>
                    <div class="form-group">
                      <label>Status</label>
                      <select name="status" class="form-control select2" id="status_PlanP">
                        <option value="Activo">Activo</option>
                        <option value="Inactivo">Inactivo</option>
                      </select>
                    </div>                                  
                </center>
            </div>
            <div class="tab-pane fade" id="pills-pago" role="tabpanel" aria-labelledby="pills-pago-tab">
                <center>
                    <div class="form-group" id="pagoRealizado">
                        <div class="">                  
                            <label for="admins_todos">¿Se realizó el pago?</label>
                            <input type="checkbox" name="admins_todos" onchange="TodosAdmins()" id="todoAdmin"  data-toggle="tooltip" data-placement="top" title="Seleccione si el pago se realizó correctamente" value="1">
                        </div>
                        <label>Referencia <b class="text-danger">*</b></label>
                        <input type="text" class="form-control" name="referencia" maxlength="20" required>
                    </div>
                    <div class="row">
                        <?php $num=0; ?>
                            <?php $__currentLoopData = $planesPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($num==0): ?>
                                    <div class="col-md-6">
                                        <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                            <div class="card-body">
                                                <div class="custom-control custom-radio mb-2">
                                                  <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>" checked>
                                                </div>
                                               <h3><?php echo e($key->nombre); ?></h3>
                                               <span><?php echo e($key->dias); ?> dias</span>
                                               <br>
                                                <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                               <br>
                                               <center>
                                                <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                               </center>
                                            </div>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-6">
                                        <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                            <div class="card-body">
                                                <div class="custom-control custom-radio mb-2">
                                                  <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>">
                                                </div>
                                               <h3><?php echo e($key->nombre); ?></h3>
                                               <span><?php echo e($key->dias); ?> dias</span>
                                               <br>
                                                <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                               <br>
                                               <center>
                                                <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                               </center>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php $num++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </center>
            </div>
          </div>
          <div align="center">
              <button type="submit" class="btn btn-success">Guardar</button>
          </div>
        <?php echo Form::close(); ?>

    </div>
  </div>
</div><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/alquiler/layouts_arriendo/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1>Mensualidades</h1>
            </div>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card">
            <div class="card-body">
                
                <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12 offset-md-9">
                        <a class="btn btn-success" data-toggle="modal" data-target="#crearMensualidad" style="border-radius: 30px; color: white;">
                            <span> Nueva Mensualidad </span>
                        </a>
                    </div>
                </div>
            </div>
                    
        
            <div class="col-md-12">
                <hr>

                <table class="table table-hover" id="myTable" width="100%">
                    <thead>
                        <tr>
                            <th>Inmueble</th>
                            <th>Mes</th>
                            <th>Año</th>
                            <th>Monto</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mensualidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key->inmuebles->idem); ?></td>
                                <td><?php echo e($key->mes); ?></td>
                                <td><?php echo e($key->anio); ?></td>
                                <td><?php echo e($key->monto); ?></td>
                                <td>
                                    <!-- <a href="#" data-toggle="modal" onclick="Editar('<?php echo e($key->id); ?>','<?php echo e($key->inmuebles->id); ?>','<?php echo e($key->mes); ?>','<?php echo e($key->anio); ?>','<?php echo e($key->monto); ?>')" data-target="#editarMensualidad" class="btn btn-warning btn-sm">Editar</a> -->

                                    <a href="#" data-toggle="modal" onclick="Eliminar('<?php echo e($key->id); ?>')" data-target="#eliminarMensualidad" class="btn btn-danger btn-sm">Eliminar</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
            
        </div>
        

    </div>

    <form action="<?php echo e(route('mensualidades.store')); ?>" method="POST" name="registrar_mensualidad" data-parsley-validate>
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="crearMensualidad" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Nueva Mensualidad</h4>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" name="id_inmueble" placeholder="Inmueble" class="form-control">
                                        <?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key->id); ?>"> <?php echo e($key->idem); ?> - <?php echo e($key->tipo); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" multiple="multiple" name="mes[]" placeholder="Inmueble" class="form-control">
                                        <option value="" disabled="" selected="">Especifique el mes</option>
                                        <option value="1">Enero</option>
                                        <option value="2">Febrero</option>
                                        <option value="3">Marzo</option>
                                        <option value="4">Abril</option>
                                        <option value="5">Mayo</option>
                                        <option value="6">Junio</option>
                                        <option value="7">Julio</option>
                                        <option value="8">Agosto</option>
                                        <option value="9">Septiembre</option>
                                        <option value="10">Octubre</option>
                                        <option value="11">Noviembre</option>
                                        <option value="12">Diciembre</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" name="anio" placeholder="Inmueble" class="form-control">
                                        <option value="" disabled="" selected="">Especifique el año</option>
                                        <option value="2020">2020</option>
                                        <option value="2021">2021</option>
                                        <option value="2022">2022</option>
                                        <option value="2023">2023</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="number" name="monto" class="form-control" placeholder="Monto a especificar">
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" >Guardar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!-- <form method="POST">
        <div class="modal fade" id="editarMensualidad" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Editar Mensualidad</h4>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" name="id_inmueble" placeholder="Inmueble" class="form-control">
                                        
                                    </select>
                                </div>
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" name="mes" placeholder="Inmueble" class="form-control">
                                        
                                    </select>
                                </div>
                            </div>
                        </div>

                         <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" name="anio" placeholder="Inmueble" class="form-control">
                                        
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="number" name="monto" class="form-control" placeholder="Monto a especificar">
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <select type="text" name="status" placeholder="Status del Mensualidad" class="form-control">
                                    	<option value="Cancelado">Cancelado</option>
                                    	<option value="Pendiente">Pendiente</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="id">
                        <button type="submit" class="btn btn-success" >Editar</button>
                    </div>
                </div>
            </div>
        </div>
    </form> -->

     <?php echo Form::open(['route' => ['mensualidades.destroy',1033], 'method' => 'DELETE']); ?>

        <div class="modal fade" id="eliminarMensualidad" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Eliminar Mensualidad</h4>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h2>¡Atención!</h2>
                        <h4>¿Está realmente seguro de querer eliminar esta mensualidad?</h4>
                    </div>
                    <div class="modal-footer">
                        <input type="hidden" name="id" id="id">
                        <button type="submit" class="btn btn-success" >Eliminar</button>
                    </div>
                </div>
            </div>
        </div>
    <?php echo Form::close(); ?>

    

<?php $__env->stopSection(); ?>

<script type="text/javascript">
        // function Editar(id, id_inmueble, mes, año, monto) {
        //     // alert('asdasd');
        //     $('#id_e').val(id);
        //     $('#idem_e').val(idem);
        //     $('#tipo_e').val(tipo);
        //     $('#status_e').val(status);
        // }
        
    </script>
    <script type="text/javascript">

        function Eliminar(id) {
            $('#id').val(id);
        }
    </script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/mensualidades/index.blade.php ENDPATH**/ ?>
<?php echo Form::open(['route' => ['registrar_incidencia'], 'enctype' => 'multipart/form-data', 'method' => 'POST', 'name' => 'registrar_incidencia', 'id' => 'registrar_incidencia', 'data-parsley-validate']); ?>

        <?php echo csrf_field(); ?>
    <div class="modal fade" id="crearIncidencia" role="dialog">
        <div class="modal-dialog modals-default border border-danger">
            <div class="modal-content">
                <div class="modal-header">
                    <h4>Reportar incidencia</h4>
                    <button type="button" class="close" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Las indicidencias se agragarán como recargas a los residentes por daños en los equipos e instalaciones</p>
                    <center>
                        <div class="form-group">
                            <label>Residente</label>
                            <select class="form-control select2" id="id_residente" onchange="buscarTodo(this.value)" name="id_residente" required>
                                <option disabled>Seleccione residente</option>
                                <?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key->id); ?>"><?php echo e($key->nombres); ?> <?php echo e($key->apellidos); ?> - <?php echo e($key->rut); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Motivo</label>
                            <input type="text" name="motivo" class="form-control" required placeholder="Romper ventanas de la oficina">
                        </div>
                        <div class="form-group">
                            <label>Observación (Opcional)</label>
                            <textarea class="form-control" name="observacion" placeholder="¿Algo que desee acotar?"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Monto</label>
                            <input type="number" name="monto" class="form-control" placeholder="15000" required>
                    </center>
                    <div align="center">
                        <button type="submit" class="btn btn-danger">Guardar incidencia</button>
                    </div>
                </div>                            
            </div>
        </div>
    </div>
<?php echo Form::close(); ?><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/alquiler/layouts/incidencia.blade.php ENDPATH**/ ?>
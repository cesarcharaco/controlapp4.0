<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                ControlApp <label class="badge badge-soft-danger">v1.0.1.</label> Un proyecto desarrollado por <a href="https://eiche.cl/" target="_blank" id="eiche">EICHE</a>.
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/layouts/admin/footer.blade.php ENDPATH**/ ?>
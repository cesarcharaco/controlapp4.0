<?php $__env->startSection('content'); ?>

    <style type="text/css">
        .palabraVerInmueble2, .palabraVerEstaciona2,.PalabraEditarPago2, .tituloTabla2
        {
            display: none;
        }
        @media  only screen and (max-width: 800px)  {

            .PalabraEditarPago, .PalabraRealizarPago, .PalabraPagoConfirmar{
                display: none;
            }
            .palabraVerInmueble{
                display: none;
            }
            .palabraVerInmueble2{
                display: block;
            }
            .palabraVerEstaciona{
                display: none;
            }
            .palabraVerEstaciona2{
                display: block;
            }
            .PalabraEditarPago2{
                display: block;
            }
            .iconosMetaforas{
                display: none;    
            }
            .card-table{
                width: 100%
            }

        }
        @media  only screen and (max-width: 200px)  {
            .botonesEditEli{
                width: 15px;
                height: 15px;
            }
            .iconosMetaforas2{
                width: 5px;
                height: 5px;    
            }
        }
        @media  screen and (max-width: 480px) {
            .tituloTabla{
                display: none;
            }
            .tituloTabla2{
                display: block;
            }
            .iconosMetaforas2{
                width: 15px;
                height: 15px;    
            }
            .botonesEditEli{
                width: 30px;
                height: 30px;
                margin-top: 5px;
                    
            }
        }


    </style>
    <div class="container">
        <input type="hidden" id="colorView" value="#25c2e3 !important">
        <div class="row page-title">
            <div class="col-md-12">
                <nav aria-label="breadcrumb" class="float-right mt-1">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Root</li>
                    </ol>
                </nav>
                <h4 class="mb-1 mt-0">Root</h4>
            </div>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(count($errors)): ?>
        <div class="alert-list m-4">
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($error); ?>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <div class="card border border-info rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="display: none;">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="row">
                    <div class="col-md-12 offset-md-12">
                        <a class="btn btn-success boton-tabla shadow" id="btnRegistrar_admin" data-toggle="modal" data-target="#crearAdmin" style="
                            border-radius: 10px;
                            color: white;
                            height: 35px;
                            margin-bottom: 5px;
                            margin-top: 5px;
                            float: right;">
                            <span class="PalabraEditarPago ">Nuevo Admin</span>
                            <center>
                                <span class="PalabraEditarPago2 ">
                                    <i data-feather="plus" class="iconosMetaforas2"></i>
                                </span>
                            </center>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div style="width: 100%;">
                        <?php echo $__env->make('root.layouts.showAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="col-md-12">
                <div id="example1_wrapper">
                    <table class="table dataTable data-table-basic table-curved table-striped tabla-estilo" style="width: 100%;">
                        <thead>
                            <tr class="table-default text-white">
                                <td colspan="6" align="center">
                                    <div class="card border border-info" style="background-color: #D6EAF8" role="alert">
                                        <span class="text-dark p-1 mb-1"><strong>Aviso: </strong><br>-Seleccione a un usuario administrador para ver mas opciones.</span>
                                    </div>
                                </td>
                            </tr>
                            <tr class="bg-primary text-white" id="th2" style="display: none">
                                <th width="10"></th>
                                <th>
                                    <span class="PalabraEditarPago">Nombres</span>
                                    <span class="PalabraEditarPago2">N</span>
                                </th>
                                <th>
                                    <span class="PalabraEditarPago">Rut</span>
                                    <span class="PalabraEditarPago2">R</span>
                                </th>
                                <th colspan="2">
                                    <center>
                                        <span class="PalabraEditarPago">Opciones</span>
                                        <span class="PalabraEditarPago2">O</span>
                                    </center>
                                </th>
                                <th>
                                    <span class="PalabraEditarPago">Status</span>
                                    <span class="PalabraEditarPago2">S</span>
                                </th>
                            </tr>
                            <tr class="bg-info text-white" id="th1">
                                <th style="width: 1px !important;">#</th>
                                <th>
                                    <span class="PalabraEditarPago">Nombres</span>
                                    <span class="PalabraEditarPago2">N</span>
                                </th>
                                <th>
                                    <span class="PalabraEditarPago">Rut</span>
                                    <span class="PalabraEditarPago2">R</span>
                                </th>
                                <th>
                                    <span class="PalabraEditarPago">Email</span>
                                    <span class="PalabraEditarPago2">@</span>
                                </th>
                                <th>
                                    <span class="PalabraEditarPago">Registrado el</span>
                                    <span class="PalabraEditarPago2">R</span>
                                </th>
                                <th>
                                    <span class="PalabraEditarPago">Status</span>
                                    <span class="PalabraEditarPago2">S</span>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $num=0 ?>
                            <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="vista1-<?php echo e($key->id); ?>" onclick="opcionesTabla(1,'<?php echo e($key->id); ?>')">
                                    <td align="center">
                                        <?php echo e($num=$num+1); ?>

                                    </td>
                                    <td style="position: all;"><?php echo e($key->name); ?></td>
                                    <td style="position: all;"><?php echo e($key->rut); ?></td>
                                    <td style="position: all;"><?php echo e($key->email); ?></td>
                                    <td style="position: all;"><?php echo e($key->created_at); ?></td>
                                     <?php if($key->status == 'activo'): ?>
                                        <td style="position: all;">
                                                <span class="tituloTabla text-success"><strong>Activo</strong></span>
                                                <span class="tituloTabla2 text-success"><strong>A</strong></span>
                                        </td>
                                    <?php else: ?>
                                        <td style="position: all;">
                                                <span class="tituloTabla text-danger"><strong>Inactivo</strong></span>
                                                <span class="tituloTabla2 text-danger"><strong>I</strong></span>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                                <tr id="vista2-<?php echo e($key->id); ?>" class="table-success" style="display: none;">
                                    <td width="10">
                                        <button class="btn btn-success btn-sm boton-tabla shadow botonesEditEli" onclick="opcionesTabla(2,'<?php echo e($key->id); ?>')">
                                            <span class="PalabraEditarPago ">Regresar</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="arrow-left" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </button>
                                    </td>
                                    <td>
                                        <span><?php echo e($key->name); ?></span>
                                    </td>
                                    <td>
                                        
                                        <span><?php echo e($key->rut); ?></span>
                                    </td>
                                    <td style="display: none"></td>
                                    <td align="center" colspan="2">

                                        <a data-toggle="collapse" href="#verAdmin" role="button" aria-expanded="false" aria-controls="verAdmin" class="btn btn-success btn-sm" onclick="verAdmin()">
                                            <span class="PalabraEditarPago ">Ver</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="edit" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </a>

                                        <a href="#" class="btn btn-warning btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;" data-toggle="modal" data-target="#editarResidente" onclick="Editar('<?php echo e($key->id); ?>','<?php echo e($key->name); ?>','<?php echo e($key->rut); ?>','<?php echo e($key->email); ?>','<?php echo e($key->status); ?>','<?php echo e($key->membresia->nombre); ?>','<?php echo e($key->membresia->cant_inmuebles); ?>','<?php echo e($key->membresia->monto); ?>','<?php echo e($key->link_flow); ?>','<?php echo e($key->link_tb); ?>')">
                                            <span class="PalabraEditarPago ">Editar</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="edit" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </a>

                                        <a href="#" class="btn btn-danger btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;"data-toggle="modal" data-target="#eliminarResidente" onclick="Eliminar('<?php echo e($key->id); ?>')">
                                            <span class="PalabraEditarPago ">Eliminar</span>
                                            <center>
                                                <span class="PalabraEditarPago2 ">
                                                    <i data-feather="trash" class="iconosMetaforas2"></i>
                                                </span>
                                            </center>
                                        </a>
                                    </td>
                                    <?php if($key->status == 'activo'): ?>
                                        <td style="position: all;">
                                                <span class="tituloTabla text-success"><strong>Activo</strong></span>
                                                <span class="tituloTabla2 text-success"><strong>A</strong></span>
                                        </td>
                                    <?php else: ?>
                                        <td style="position: all;">
                                                <span class="tituloTabla text-danger"><strong>Inactivo</strong></span>
                                                <span class="tituloTabla2 text-danger"><strong>I</strong></span>
                                        </td>
                                    <?php endif; ?>


                                </tr>
                            <!-- <tr style="display: none;">
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr> -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

        




<?php echo $__env->make('root.modales.crearAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('root.modales.eliminarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('root.modales.editarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
$('#check_flow').on('change',function () {
    if ($('#check_flow').prop('checked')) {
      $('#link_flow').attr('disabled',false);
      $("#link_flow").prop('required', true);
    }else{
      $('#link_flow').attr('disabled',true);
      $("#link_flow").removeAttr('required');
      link_flow.value="";
    }
  });    
</script>
<script>
$('#check_tb').on('change',function () {
    if ($('#check_tb').prop('checked')) {
      $('#link_tb').attr('disabled',false);
      $("#link_tb").prop('required', true);
    }else{
      $('#link_tb').attr('disabled',true);
      $("#link_tb").removeAttr('required');
      link_tb.value="";
    }
  });    
</script>

<script>
$('#check_flow_edit').on('change',function () {
    if ($('#check_flow_edit').prop('checked')) {
      $('#link_flow_edit').attr('disabled',false);
      $("#link_flow_edit").prop('required', true);
    }else{
      $('#link_flow_edit').attr('disabled',true);
      $("#link_flow_edit").removeAttr('required');
    }
  });    
</script>
<script>
$('#check_tb_edit').on('change',function () {
    if ($('#check_tb_edit').prop('checked')) {
      $('#link_tb_edit').attr('disabled',false);
      $("#link_tb_edit").prop('required', true);
    }else{
      $('#link_tb_edit').attr('disabled',true);
      $("#link_tb_edit").removeAttr('required');
    }
  });    
</script>

<script type="text/javascript">

    function cerrar(opcion) {
      $('#example1_wrapper').fadeIn('fast');
      $('#btnRegistrar_admin').show();
    }

    function verAdmin() {
        $('#btnRegistrar_admin').fadeOut('fast');
        $('#example1_wrapper').fadeOut('fast');
    }
        function Editar(id,name,rut,email,status,membresia_nombre,membresia_cant,membresia_monto,link_flow, link_tb) {
            $('#editarAdmin').modal('show');
            $('#id_admin_e').val(id);
            $('#name_e').val(name);
            $('#rut_e').val(rut.substr(0,(rut.length-2)));
            $('#verificador_e').val(rut.substr(-1,(rut.length)));
            $('#email_e').val(email);
            $('#status_e').val(status);
            $("#membresia_e").append('<input id="membresia_actual" class="form-control" value="'+membresia_nombre+' | Cant. Inmuebles: '+membresia_cant+' | Monto: '+membresia_monto+'" disabled="disabled">');
            $('#link_flow_edit').val(link_flow);
            $('#link_tb_edit').val(link_tb);
        }

        function CambiarContraseña() {
            if($('#CheckCambiarContraseña').prop('checked')){

                $('#verCambiarContraseña').fadeIn(300);
                $('#contraseñaE').attr('required',true);
                $('#confirmarContraseñaE').attr('required',true);
                
            }else{

                $('#verCambiarContraseña').fadeOut('slow',
                    function() { 
                        $(this).css('display','none');
                });
                $('#contraseñaE').removeAttr('required',false);
                $('#confirmarContraseñaE').removeAttr('required',false);               
            }
        }

        function CambiarPagos() {
            if($('#CheckCambiarPagos').prop('checked')){

                $('#verCambiarPagos').fadeIn(300);
                $('#contraseñaE').attr('required',true);
                $('#confirmarContraseñaE').attr('required',true);
                
            }else{

                $('#verCambiarPagos').fadeOut('slow',
                    function() { 
                        $(this).css('display','none');
                });
                $('#contraseñaE').removeAttr('required',false);
                $('#confirmarContraseñaE').removeAttr('required',false);               
            }
        }

        function CambiarMembresia() {
            if($('#CheckCambiarMembresia').prop('checked')){

                $('#verCambiarMembresia').fadeIn(300);
                $('#contraseñaE').attr('required',true);
                $('#confirmarContraseñaE').attr('required',true);
                
            }else{

                $('#verCambiarMembresia').fadeOut('slow',
                    function() { 
                        $(this).css('display','none');
                });
                $('#contraseñaE').removeAttr('required',false);
                $('#confirmarContraseñaE').removeAttr('required',false);               
            }
        }
        function agregarPasarelas() {
            if($('#CheckagregarPasarelas').prop('checked')){

                $('#pasarelas_pago').fadeIn(300);
                $('#id_pasarela').attr('required',true);
                $('#link_pasarela').attr('required',true);
                
            }else{

                $('#pasarelas_pago').fadeOut('slow',
                    function() { 
                        $(this).css('display','none');
                });
                $('#id_pasarela').removeAttr('required',false);
                $('#link_pasarela').removeAttr('required',false);               
            }
        }
        
    </script>
    <script type="text/javascript">

        function Eliminar(id) {
            $('#eliminarAdmin').modal('show');
            $('#id_admin').val(id);
        }
        // function decimal(valor) {
        //     alert(valor.length);
        //     var valor2='';

        //     if(valor.length=<3){
        //         valor2=String(valor.substr(1,2,3)+'.'+valor.substr(4,5,6));
        //     }

        //     alert(valor2);



        // }
    </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/root/index.blade.php ENDPATH**/ ?>
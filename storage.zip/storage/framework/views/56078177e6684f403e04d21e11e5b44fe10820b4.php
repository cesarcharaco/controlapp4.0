<div class="modal fade" id="VerMensualidades" role="dialog">
    <div class="modal-dialog modals-default">
        <div class="modal-content">
            <div class="modal-header">
                <h4>Ver Mensualidades</h4>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <center>
                    <div id="fechasM"></div>
                    <div id="buttonShow"></div>
                    <div id="MesesM"></div>
                    <input type="hidden" name="id" id="idShowM">
                </center>
            </div>                            
        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\controlapp3.0\resources\views/inmuebles/layouts/ver_mensualidad.blade.php ENDPATH**/ ?>
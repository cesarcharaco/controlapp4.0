<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <?php if(\Auth::user()->tipo_usuario=="Admin"): ?>
            <?php if(count($anuncios) >0 && \Auth::user()->tipo_usuario!="Admin"): ?>
                <div class="col-md-9">
                <div style="margin-right: -25px;">
            <?php else: ?>
                <div class="col-md-12" style="margin-right: 25px;">
                <div style="margin-right: 0px;">
            <?php endif; ?>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="row page-title">
                        <div class="col-md-12">
                            <nav aria-label="breadcrumb" class="float-right mt-1">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                </ol>
                            </nav>
                            <h4 class="mb-1 mt-0">Vista Principal</h4>
                        </div>
                    </div>
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(!empty($errors->all())): ?>
                        <div class="notification is-danger">
                            <h4 class="is-size-4">Por favor, valida los siguientes errores:</h4>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <?php echo e($mensaje); ?>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="row">
                        <div class="col-md-6 col-xl-6">
                            <div class="card border border-info rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="display: none;">
                                <div class="card-body p-0">
                                    <div class="media p-4">
                                        <div class="media-body">
                                            <span class="text-info text-uppercase font-size-12 font-weight-bold">Pago Comúnes</span>
                                            <div class="row">
                                                <div class="col-lg-4 col-md-4">
                                                    <h6 style="margin-top: 24px;color: #CB8C4D !important;" align="center">Costo Inmueble</h6>
                                                </div>
                                                <div class="col-lg-4 col-md-4">
                                                    <h6><a href="#" style="width: 100% !important;" onclick="PagoC(1)" class="btn btn-primary shadow">Registrar</a></h6>
                                                </div>
                                                <div class="col-lg-4 col-md-4">
                                                    <h6><a href="#" style="width: 100% !important;" onclick="PagoC(3)" class="btn btn-warning shadow">Editar</a></h6>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-lg-4 col-md-4">
                                                    <h6 style="margin-top: 10px;color: #cccc00 !important;" align="center">Costo Estacionamiento</h6>
                                                </div>
                                                <div class="col-lg-4 col-md-4">
                                                    <h6><a href="#" style="width: 100% !important;" onclick="PagoC(2)" class="btn btn-primary shadow">Registrar</a></h6>
                                                </div>
                                                <div class="col-lg-4 col-md-4">
                                                    <h6><a href="#" style="width: 100% !important;" onclick="PagoC(4)" class="btn btn-warning shadow">Editar</a></h6>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-6">
                            <div class="card rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="
                                    display: none;
                                    border: 1px solid #f6f6f7!important;
                                    border-color: #2d572c !important;
                                    ">
                                <div class="card-body p-0">
                                    <div class="media">
                                        <div class="media-body">
                                            <center><span class="text-success text-uppercase font-size-12 font-weight-bold" style="color:#2d572c !important;">Residentes</span></center>
                                            <div class="row justify-content-center">
                                                <div class="col-md-6">
                                                    <div class="card shadow" style="border: 1px solid #f6f6f7!important; border-color: #2d572c !important;">
                                                        <table width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td align="center"><span>Registrados: </span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center"><?php echo e(residentes()); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center"><span style="color: #CB8C4D !important;">C/Inmuebles:</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center"><?php echo e(residentes_alquilados_i()); ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center"><span style="color: #cccc00 !important;">C/Estaciona.:</span></td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center"><?php echo e(residentes_alquilados_e()); ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group" align="center">
                                                        <label style="color: #2d572c !important;">Nuevo Residente</label>
                                                        <a href="#" style="
                                                            width: 100% !important;
                                                            position: relative;
                                                            border: 1px solid #f6f6f7!important;
                                                            border-color: #2d572c !important;
                                                            background-color: #2d572c !important;" class="btn shadow" onclick="NuevoResidente()"><strong class="text-white">Agregar</strong>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-6 col-xl-6">
                            <div class="card rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="
                                display: none;
                                border: 1px solid #f6f6f7!important;
                                border-color: #CB8C4D !important; ">
                                <div class="card-body p-0">
                                    <div class="media p-2">
                                        <div class="media-body">
                                            <center>
                                                <span class="text-success text-uppercase font-size-12 font-weight-bold" style="color: #CB8C4D  !important">Inmuebles</span>
                                            </center>
                                            <div class="row justify-content-center">
                                                <div class="col-md-6">
                                                    <div class="card shadow" style="border: 1px solid #f6f6f7!important; border-color: #CB8C4D !important;">
                                                        <table width="100%">
                                                            <tbody>
                                                                <tr>
                                                                        <td align="center"><span>Existencias:</span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="center"><?php echo e(existencia_i()); ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="center"><span>Alquilados:</span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="center"><?php echo e(alquilados_i_t()); ?></td>
                                                                    </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group" align="center">
                                                        <label class="mb-0" style="color: #CB8C4D !important">Nuevo Inmueble</label>
                                                        <h6 class="mb-0">
                                                            <strong>
                                                                <a href="#" data-toggle="modal" data-target="#crearInmueble" style="
                                                                    width: 100% !important;
                                                                    position: relative;
                                                                    border: 1px solid #f6f6f7!important;
                                                                    border-color: #CB8C4D !important; 
                                                                    background-color: #CB8C4D !important; " class="btn shadow"><strong class="text-white">Agregar</strong>
                                                                </a>
                                                            </strong>
                                                        </h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-xl-6">
                            <div class="card rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="
                                display: none;
                                border: 1px solid #f6f6f7!important;
                                border-color:#cccc00 !important;">
                                <div class="card-body p-0">
                                    <div class="media p-2">
                                        <div class="media-body">
                                            <center>
                                                <span class="text-uppercase font-size-12 font-weight-bold" style="color: #cccc00 !important;">Estacionamientos</span>
                                            </center>
                                            <div class="row justify-content-center">
                                                <div class="col-md-6">
                                                    <div class="card shadow" style="border: 1px solid #f6f6f7!important; border-color: #cccc00 !important;">
                                                        <table width="100%">
                                                            <tbody>
                                                                <tr>
                                                                        <td align="center"><span>Existencias:</span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="center"><?php echo e(existencia_e()); ?></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="center"><span>Alquilados:</span></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td align="center"><?php echo e(alquilados_e_t()); ?></td>
                                                                    </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="col-md-6" align="center">
                                                    <label class="mb-0" style="color: #cccc00 !important;">Nuevo Estacionamiento</label>
                                                    <h6 class="mb-0">
                                                        <strong>
                                                            <a href="#" style="
                                                            width: 100% !important;
                                                            position: relative;
                                                            border: 1px solid #f6f6f7!important;
                                                            border-color: #cccc00 !important;
                                                            background-color: #cccc00 !important;
                                                            " data-toggle="modal" data-target="#crearEstacionamiento" class="btn btn-danger shadow">Agregar</a>
                                                        </strong>
                                                    </h6>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                       

                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <div class="card border border-success rounded shadow p-3 mb-5 bg-white rounded" style="display: none;">
                                <div class="card-header">
                                    <div class="row">
                                        <div class="col-md-9">
                                            <center><h4>Notificaciones</h4></center>
                                        </div>
                                        <div class="col-md-3">
                                            <?php if(\Auth::user()->tipo_usuario=="Admin"): ?>
                                                <a style="width: 100%" href="#" data-toggle="modal" data-target="#crearNotficacion" class="btn btn-success">Nueva</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(\Auth::user()->tipo_usuario=="Admin"): ?>
                                    <h4><?php echo e($key->titulo); ?></h4>
                                        <div class="row">
                                            <div class="col-md-5">
                                                <p><?php echo e($key->motivo); ?></p>
                                            </div>
                                            <div class="col-md-5">
                                                <ul>
                                                <?php echo e(mostrar_resi_has_notif($key->id)); ?>

                                                </ul>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="dropdown align-self-center float-right">
                                                    <a href="#" class="dropdown-toggle arrow-none text-muted" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="uil uil-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-177px, 20px, 0px);">
                                                        <!-- item-->
                                                        <!-- <a href="#" class="dropdown-item" data-toggle="modal" data-target="#editarNotificacion"><i class="uil uil-edit-alt mr-2"></i>Editar</a> -->
                                                        <!-- item-->
                                                        <div class="dropdown-divider"></div>
                                                        <!-- item-->
                                                        <a href="<?php echo e(route('eliminarNotificacion', $key->id)); ?>" class="dropdown-item text-danger"><i class="uil uil-trash mr-2"></i>Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php elseif(\Auth::user()->tipo_usuario!=="Admin"): ?>
                                        <?php if($key->publicar=="Todos" || buscar_notificacion($residente->id,$key->id)>0): ?>
                                        <h4><?php echo e($key->titulo); ?></h4>
                                        <div class="row">
                                            <div class="col-md-10">
                                                <p><?php echo e($key->motivo); ?></p>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="dropdown align-self-center float-right">
                                                    <a href="#" class="dropdown-toggle arrow-none text-muted" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="uil uil-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-177px, 20px, 0px);">
                                                        <!-- item-->
                                                        <!-- <a href="#" class="dropdown-item" data-toggle="modal" data-target="#editarNotificacion"><i class="uil uil-edit-alt mr-2"></i>Editar</a> -->
                                                        <!-- item-->
                                                        <div class="dropdown-divider"></div>
                                                        <!-- item-->
                                                        <a href="<?php echo e(route('eliminarNotificacion', $key->id)); ?>" class="dropdown-item text-danger"><i class="uil uil-trash mr-2"></i>Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="card-footer">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border border-success rounded shadow p-3 mb-5 bg-white rounded" style="display: none;">
                                <div class="card-header">
                                    <div class="row">
                                        <div class="col-md-7">
                                            <center><h4>Noticias</h4></center>
                                        </div>
                                        <div class="col-md-5">
                                            <?php if(\Auth::user()->tipo_usuario=="Admin"): ?>
                                                <a style="width: 100%" href="#" data-toggle="modal" data-target="#crearNoticia" class="btn btn-success">Nueva</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    
                                    <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($key->titulo); ?></h4>
                                        <div class="row">
                                            <div class="col-md-10">
                                                <p><?php echo e($key->contenido); ?></p>
                                            </div>
                                            <div class="col-md-2">
                                                <div class="dropdown align-self-center float-right">
                                                    <a href="#" class="dropdown-toggle arrow-none text-muted" data-toggle="dropdown" aria-expanded="false">
                                                        <i class="uil uil-ellipsis-v"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-177px, 20px, 0px);">
                                                        <!-- item-->
                                                        <!-- <a href="#" class="dropdown-item" data-toggle="modal" data-target="#editarNoticia" ><i class="uil uil-edit-alt mr-2"></i>Editar</a> -->
                                                        <!-- item-->
                                                        <div class="dropdown-divider"></div>
                                                        <!-- item-->
                                                        <a href="<?php echo e(route('eliminarNoticia', $key->id)); ?>" class="dropdown-item text-danger"><i class="uil uil-trash mr-2"></i>Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="card-footer">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php elseif(\Auth::user()->tipo_usuario=="root"): ?>
            <input type="hidden" id="colorView" value="#25c2e3 !important">
            <div class="col-md-12 container-fluid">
                <br>
                <div class="row">
                    
                    <div class="col-md-8" style="float: left; position: relative;">
                        <div style="width: 100%;" id="vistaAdminRoot">
                            <div class="card border border-info rounded card-tabla shadow p-3 mb-5 bg-white rounded" style="display: none;">
                                <div class="card-body p-0">
                                        <span class="text-info text-uppercase font-size-12 font-weight-bold">Usuarios administradores</span>
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12">
                                                <a class="btn btn-success boton-tabla shadow" data-toggle="modal" data-target="#crearAdmin" style="
                                                    border-radius: 10px;
                                                    color: white;
                                                    height: 35px;
                                                    margin-bottom: 5px;
                                                    margin-top: 5px;
                                                    float: right;">
                                                    <span class="PalabraEditarPago">Agregar</span>
                                                </a>
                                            </div>
                                        </div>

                                    <table class="table dataTable data-table-basic table-curved table-striped tabla-estilo" style="width: 100%;">
                                        <thead>
                                            <tr class="bg-primary text-white" id="th2" style="display: none">
                                                <th>
                                                    <span>Nombres</span>
                                                </th>
                                                <th>
                                                    <span>Rut</span>
                                                </th>
                                                <th colspan="2">
                                                    <center>
                                                        <span>Opciones</span>
                                                    </center>
                                                </th>
                                                <th>
                                                    <span>Status</span>
                                                </th>
                                            </tr>
                                            <tr class="bg-info text-white" id="th1">
                                                <th>
                                                    <span>Nombres</span>
                                                </th>
                                                <th>
                                                    <span>Rut</span>
                                                </th>
                                                <th>
                                                    <span>Email</span>
                                                </th>
                                                <th>
                                                    <span>Registrado el</span>
                                                </th>
                                                <th>
                                                    <span>Status</span>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="vista1-<?php echo e($key->id); ?>">

                                                    <td style="position: all;"><?php echo e($key->name); ?></td>
                                                    <td style="position: all;"><?php echo e($key->rut); ?></td>
                                                    <td style="position: all;"><?php echo e($key->email); ?></td>
                                                    <td style="position: all;"><?php echo e($key->created_at); ?></td>
                                                     <?php if($key->status == 'activo'): ?>
                                                        <td style="position: all;">
                                                                <span class="tituloTabla text-success"><strong>Activo</strong></span>
                                                                <span class="tituloTabla2 text-success"><strong>A</strong></span>
                                                        </td>
                                                    <?php else: ?>
                                                        <td style="position: all;">
                                                                <span class="tituloTabla text-danger"><strong>Inactivo</strong></span>
                                                                <span class="tituloTabla2 text-danger"><strong>I</strong></span>
                                                        </td>
                                                    <?php endif; ?>
                                                </tr>
                                                <tr id="vista2-<?php echo e($key->id); ?>" class="table-success" style="display: none;">
                                                    <td width="10">
                                                        <button class="btn btn-success btn-sm boton-tabla shadow botonesEditEli" onclick="opcionesTabla(2,'<?php echo e($key->id); ?>')">
                                                            <span class="PalabraEditarPago ">Regresar</span>
                                                            <center>
                                                                <span class="PalabraEditarPago2 ">
                                                                    <i data-feather="arrow-left" class="iconosMetaforas2"></i>
                                                                </span>
                                                            </center>
                                                        </button>
                                                    </td>
                                                    <td>
                                                        <span><?php echo e($key->name); ?></span>
                                                    </td>
                                                    <td>
                                                        
                                                        <span><?php echo e($key->rut); ?></span>
                                                    </td>
                                                    <td style="display: none"></td>
                                                    <td align="center" colspan="2">
                                                        <a href="#" class="btn btn-warning btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;" data-toggle="modal" data-target="#editarResidente" onclick="Editar('<?php echo e($key->id); ?>','<?php echo e($key->name); ?>','<?php echo e($key->rut); ?>','<?php echo e($key->email); ?>','<?php echo e($key->status); ?>')">
                                                            <span class="PalabraEditarPago ">Editar</span>
                                                            <center>
                                                                <span class="PalabraEditarPago2 ">
                                                                    <i data-feather="edit" class="iconosMetaforas2"></i>
                                                                </span>
                                                            </center>
                                                        </a>

                                                        <a href="#" class="btn btn-danger btn-sm boton-tabla shadow botonesEditEli" style="border-radius: 5px;"data-toggle="modal" data-target="#eliminarResidente" onclick="Eliminar('<?php echo e($key->id); ?>')">
                                                            <span class="PalabraEditarPago ">Eliminar</span>
                                                            <center>
                                                                <span class="PalabraEditarPago2 ">
                                                                    <i data-feather="trash" class="iconosMetaforas2"></i>
                                                                </span>
                                                            </center>
                                                        </a>
                                                    </td>
                                                    <?php if($key->status == 'activo'): ?>
                                                        <td style="position: all;">
                                                                <span class="tituloTabla text-success"><strong>Activo</strong></span>
                                                                <span class="tituloTabla2 text-success"><strong>A</strong></span>
                                                        </td>
                                                    <?php else: ?>
                                                        <td style="position: all;">
                                                                <span class="tituloTabla text-danger"><strong>Inactivo</strong></span>
                                                                <span class="tituloTabla2 text-danger"><strong>I</strong></span>
                                                        </td>
                                                    <?php endif; ?>


                                                </tr>
                                            <!-- <tr style="display: none;">
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                            </tr> -->
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-md-4">
                        <div style="margin-top: -30px; width: auto;" id="anuncioRoot">
                            <table class="table table-striped">
                                <thead>
                                    <th>
                                        <strong class="text-dark" style="font-size: 20px;">Anuncios</strong>
                                        <a href="#" style="float: right" class="btn btn-success btn-sm" onclick="AnuncioCreate()">
                                            <span class="PalabraEditarPago">Crear anuncio</span>
                                            <span class="PalabraEditarPago2">
                                                <i data-feather="plus" class="iconosMetaforas2"></i>
                                            </span>
                                        </a>
                                    </th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="background-color: white;">
                                            <td align="center">
                                                <a href="#" style="border-radius: 50px; width: 28px; height: 28px;" onclick="VerAdminAsignado('<?php echo e($key->id); ?>')" class="btn btn-info btn-sm">
                                                    a
                                                </a>
                                                <!-- <a href="#" style="border-radius: 50px; width: 28px; height: 28px;" onclick="EditarAnuncio('<?php echo e($key->id); ?>','<?php echo e($key->titulo); ?>','<?php echo e($key->descripcion); ?>','<?php echo e($key->url_img); ?>','<?php echo e($key->link); ?>')" class="btn btn-warning btn-sm">
                                                    e
                                                </a> -->
                                                <a href="#" style="border-radius: 50px; width: 28px; height: 28px;" onclick="EliminarAnuncio('<?php echo e($key->id); ?>')" class="btn btn-danger btn-sm">
                                                    x
                                                </a>

                                                <div onclick="window.open('<?php echo e($key->link); ?>', '_blank');">
                                                    
                                                    <span class="text-dark"><strong><?php echo e($key->titulo); ?></strong></span>
                                                    <center><img align="center" class="imagenAnun text-dark" src="<?php echo e(asset($key->url_img)); ?>" style="width: 100%; padding: 15px 15px 15px 15px; border-radius: 10%;" ></center>

                                                    <p class="text-dark" align="center"><?php echo e($key->descripcion); ?></p>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php if(count($anuncios)>0): ?>
                <div class="col-md-9">
                <div style="margin-right: -10px;">
            <?php else: ?>
                <div class="col-md-12" style="margin-right: 25px;">
                <div style="margin-right: 0px;">
            <?php endif; ?>
                <div class="row justify-content-center">
                    <div class="col-md-12">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="row page-title">
                        <div class="col-md-12">
                            <nav aria-label="breadcrumb" class="float-right mt-1">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>
                                </ol>
                            </nav>
                            <h4 class="mb-1 mt-0">Vista Principal</h4>
                        </div>
                    </div>
                        <?php if(!empty($errors->all())): ?>
                            <div class="notification is-danger">
                                <h4 class="is-size-4">Por favor, valida los siguientes errores:</h4>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($mensaje); ?>

                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="row">
                            <div class="col-md-6 col-xl-6">
                                <div class="card border border-primary rounded shadow p-3 mb-5 bg-white rounded" style="display: none;">
                                    <input type="hidden" name="id_residente" id="id_reside" value="<?php echo e(\Auth::user()->id); ?>">
                                    <div class="card-body p-0">
                                        <div class="media p-3">
                                            <div class="media-body">
                                                <span class="text-primary text-uppercase font-size-12 font-weight-bold">Pago de Condominio</span>
                                                <h6 class="mb-0">Pagos Retrasados: </h6>
                                            </div>                                             
                                            <div class="form-group">
                                                <!-- <label class="mb-0 text-primary">Pagar mes</label> -->
                                                <h6 class="mb-0"><a href="#" style="width: 100% !important;" onclick="BMesesResidente('<?php echo e($residente->id); ?>')" class="btn btn-primary">Pagar</a></h6>
                                            </div>                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="card border border-danger rounded shadow p-3 mb-5 bg-white rounded" style="display: none;">
                                    <div class="card-body p-0">
                                        <div class="media p-3">
                                            <div class="media-body">
                                                <span class="text-danger text-uppercase font-size-12 font-weight-bold">Multas/Recargas Asignadas</span>
                                                <h6 class="mb-0">Total de Multas/Recargas: </h6>
                                            </div>
                                            
                                            <div class="form-group">
                                                <!-- <label class="mb-0 text-danger">Pagar multa</label> -->
                                                <h6 class="mb-0"><a href="#" style="width: 100% !important; position: relative;" onclick="pagarMultasResidente('<?php echo e($residente->id); ?>')" class="btn btn-danger">Pagar</a></h6>
                                            </div>
                                        </div>
                                    </div>                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-6">
                        <div class="card border border-success rounded shadow p-3 mb-5 bg-white rounded" style="display: none;">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-12">
                                        <center><h4>Notificaciones</h4></center>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <?php $__currentLoopData = $notificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key->publicar=="Todos" || buscar_notificacion($residente->id,$key->id)>0): ?>
                                    <h4><?php echo e($key->titulo); ?></h4>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p><?php echo e($key->motivo); ?></p>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card border border-success rounded shadow p-3 mb-5 bg-white rounded" style="display: none;">
                            <div class="card-header">
                                <div class="row">
                                    <div class="col-md-12">
                                        <center><h4>Noticias</h4></center>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                
                                <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($key->titulo); ?></h4>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <p><?php echo e($key->contenido); ?></p>
                                        </div>
                                    </div>
                                    
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="card-footer">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>        
        <?php if(count($anuncios)>0): ?>
            <?php if(\Auth::user()->tipo_usuario!='Admin'): ?>
                <div class="col-md-3">
                    <div class="card anuncioRoot" style="display: none; position: absolute; margin-right: -30px;">
                            <div class="card-header">
                                <strong class="text-dark" style="font-size: 20px;">Anuncios</strong>
                            </div>
                        <div class="card-body">
                            <?php $__currentLoopData = $anuncios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div onclick="window.open('<?php echo e($key->link); ?>', '_blank');">                                    
                                    <span class="text-dark"><strong><?php echo e($key->titulo); ?></strong></span>
                                    <img class="imagenAnun text-dark" src="<?php echo e(asset($key->url_img)); ?>" width="250" height="200" style="padding: 15px 15px 15px 15px; border-radius: 10%; position: relative;">
                                    <p class="text-dark" align="center"><?php echo e($key->descripcion); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        
    </div>

<?php endif; ?>


    <!-- -----------------------------------------------MODALES -------------------------------------->
    <form action="<?php echo e(route('noticias.store')); ?>" method="POST" name="registrar_noticia" data-parsley-validate>
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="crearNoticia" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Nueva Noticia</h4>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                
                                <div class="form-group">
                                    <input type="text" name="titulo" placeholder="Título" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" name="contenido" placeholder="Contenido" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" >Guardar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <form action="<?php echo e(route('notificaciones.store')); ?>" method="POST" name="registrar_notificacion" data-parsley-validate>
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="crearNotficacion" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Nueva Notificación</h4>
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                
                                <div class="form-group">
                                    <input type="text" name="titulo" required="required" placeholder="Título" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="text" name="motivo" required="required" placeholder="Motivo" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="checkbox" name="todos" onchange="bloquear(this)" id="todos"  data-toggle="tooltip" data-placement="top" checked="checked" title="Seleccione si desea que la notificación sea para todos" >
                                    <label for="todos">Para Todos</label>
                                    
                                    <select name="id_residente[]" disabled="disabled" id="id_residente" multiple="multiple" class="form-control select2">
                                        <option value="#" disabled="disabled">Seleccione El/Los Residente(s)</option>
                                        <?php $__currentLoopData = $residentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key->id); ?>"> <?php echo e($key->apellidos); ?>, <?php echo e($key->nombres); ?> - RUT: <?php echo e($key->rut); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" >Guardar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

     <?php echo Form::open(['route' => ['anuncios.update',1], 'enctype' => 'multipart/form-data', 'method' => 'PUT', 'name' => 'editar_anunc', 'id' => 'editar_anunc', 'data-parsley-validate']); ?>

        <?php echo csrf_field(); ?>
        <div class="modal fade" id="editarAnuncio" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Editar anuncio</h4>                
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Título del anuncio</label>
                                    <input type="text" id="tituloAnunE" class="form-control" placeholder="Ej: Nuevos modelos de autos" name="titulo" required>
                                </div>
                            </div>
                       
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Link</label>
                                    <input type="url" id="urlAnunE" placeholder="Ej: https://www.google.co.ve/" class="form-control" name="link" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Descripción</label>
                                    <textarea id="descripAnunE" placeholder="Ej: ¡Con nuevos repuestos traidos desde Suiza!..." class="form-control" name="descripcion" required></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Imagen</label>
                                    <div id="mostrarImagenEditar" align="center"></div>
                                    <input id="imagenAnunE" type="file" class="form-control" id="example-fileinput" name="imagen">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" class="form-control" name="id_anuncio" required id="idAnuncioE">
                        <div class="float-right">
                            <button type="submit" class="btn btn-success" >Editar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php echo Form::close(); ?>


    <form action="<?php echo e(route('anuncios.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal fade" id="crearAnuncio" role="dialog">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Nuevo anuncio</h4>                
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <ul class="nav nav-pills nav-fill mb-3" id="pills-tab" role="tablist" style="background-color: #C5C5C5 !important;">
                          <li class="nav-item">
                            <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-empresa" aria-selected="true">1</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-datos" aria-selected="false">2</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-imagen" aria-selected="false">3</a>
                          </li>
                          <li class="nav-item">
                            <a class="nav-link" id="pills-pago-tab" data-toggle="pill" href="#pills-pago" role="tab" aria-controls="pills-pago" aria-selected="false">4</a>
                          </li>
                        </ul>
                        <div class="tab-content" id="pills-tabContent">
                          <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                            <center>
                                <div class="card border border-info shadow p-3 m-4">
                                    <div class="card-body">
                                        <label for="SelectEmpresa">¿Cuál es la empresa que desea el anuncio?</label>
                                        <select class="form-control select2" name="id_empresa" required>
                                            <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key->id); ?>"><?php echo e($key->nombre); ?> .- <?php echo e($key->rut_empresa); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>                                    
                                <div class="form-group">
                                </div>
                                <div class="card border border-info shadow p-3 m-4">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label>¿Cuales administradores podrán visualizar el anuncio?</label> 
                                            <div class="">                                                                                
                                                <input type="checkbox" name="admins_todos" onchange="TodosAdmins()" id="todoAdmin"  data-toggle="tooltip" data-placement="top" title="Seleccione si desea seleccionar a todos los admins" value="1">
                                                <label for="admins_todos">Seleccionar todos</label>
                                            </div>
                                            <select name="id_admins[]" id="SelectAdminA" class="form-control select2 border border-default" multiple="multiple" >
                                                <?php $__currentLoopData = $users_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?> - RUT: <?php echo e($key->rut); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <option value="10">prueba</option>
                                            </select>

                                            <div style="display: none">
                                                <select name="id_admins[]" id="SelectAdminA2" class="form-control select2 border border-default" multiple="multiple" style="display: none;">
                                                    <?php $__currentLoopData = $users_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key->id); ?>"><?php echo e($key->name); ?> - RUT: <?php echo e($key->rut); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="10">prueba</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </center>


                          </div>
                          <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                <center>
                                    <div class="card border border-info shadow p-3 m-4">
                                        <div class="row justify-content-center">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Título del anuncio</label>
                                                    <input type="text" class="form-control" placeholder="Ej: Nuevos modelos de autos" name="titulo" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row justify-content-center">                                                       
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Link</label>
                                                    <input type="url" placeholder="Ej: https://www.google.co.ve/" class="form-control" name="link" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row justify-content-center">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Descripción</label>
                                                    <textarea placeholder="Ej: ¡Con nuevos repuestos traidos desde Suiza!..." class="form-control" name="descripcion" required></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </center>
                          </div>
                          <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                              <center>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label>Imagen</label>
                                                <div class="alert alert-primary" role="alert">
                                                    <p><strong>Recordar que:</strong><br>
                                                    - La imagen no debe exceder los 800 KB de tamaño<br>
                                                    - La imagen no debe tener una anchura mayor a 1024 kb<br>
                                                    - La imagen no debe tener una altura mayor a 800 kb</p>
                                                </div>
                                                <input type="file" class="form-control" id="example-fileinput" name="imagen" required>
                                            </div>
                                        </div>
                                    </div>
                              </center>

                          </div>

                          <div class="tab-pane fade" id="pills-pago" role="tabpanel" aria-labelledby="pills-pago-tab">
                            <center>
                                <div class="form-group">
                                    <label>Referencia</label>
                                    <input type="text" class="form-control" name="referencia" required>
                                </div>
                                <div class="row">
                                    <?php $num=0; ?>
                                    <?php if(count($promociones)>0): ?>
                                        <?php $__currentLoopData = $planesPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $__currentLoopData = $promociones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key->id == $key2->id_planP): ?> 
                                                    <?php $monto=$key->monto*$key2->porcentaje/100 ?>
                                                    <?php $monto2=$key->monto-$monto ?>
                                                    <?php if($num==0): ?>
                                                        <div class="col-md-6">
                                                            <div class="card shadow border card-tabla rounded" style="height: 400px; border: solid !important; border-color: #ff7043 !important;">
                                                                <div class="ribbon"><span>¡LIMITADO!</span></div>
                                                                <div class="ribbon2"><span>-<?php echo e($key2->porcentaje); ?>%</span></div>
                                                                <div class="card-body">
                                                                    <div class="custom-control custom-radio mb-2">
                                                                      <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>" checked>
                                                                    </div>
                                                                   <h3><?php echo e($key->nombre); ?></h3>
                                                                   <span><?php echo e($key->dias); ?> dias</span>
                                                                   <br>
                                                                    <span style="font-size: 30px;">$</span><span style="font-size: 50px;"><s><?php echo e($key->monto); ?></s></span><strong>/Mes</strong><br>
                                                                    <div style="margin-top: -30px !important;">
                                                                        <span style="font-size: 30px; color: #ff7043 !important;">$</span><span style="font-size: 70px; color: #ff7043 !important;"><?php echo e($monto2); ?></span><strong style=" color: #ff7043 !important;">/Mes</strong>
                                                                    </div>
                                                                   <br>
                                                                   <center>
                                                                    <img align="center" class="imagenAnun3" src="<?php echo e(asset($key->url_img)); ?>" style="">
                                                                   </center>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="col-md-6">
                                                            <div class="card shadow border card-tabla rounded" style="height: 400px; border: solid !important; border-color: #ff7043 !important;">
                                                                <div class="ribbon"><span>¡LIMITADO!</span></div>
                                                                <div class="ribbon2"><span>-<?php echo e($key2->porcentaje); ?>%</span></div>
                                                                <div class="card-body">
                                                                    <div class="custom-control custom-radio mb-2">
                                                                      <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>">
                                                                    </div>
                                                                   <h3><?php echo e($key->nombre); ?></h3>
                                                                   <span><?php echo e($key->dias); ?> dias</span>
                                                                   <br>
                                                                    <span style="font-size: 30px;">$</span><span style="font-size: 50px;"><s><?php echo e($key->monto); ?></s></span><strong>/Mes</strong><br>
                                                                    <div style="margin-top: -30px !important;">
                                                                        <span style="font-size: 30px; color: #ff7043 !important;">$</span><span style="font-size: 70px; color: #ff7043 !important;"><?php echo e($monto2); ?></span><strong style=" color: #ff7043 !important;">/Mes</strong>
                                                                    </div>
                                                                   <br>
                                                                   <center>
                                                                    <img align="center" class="imagenAnun3" src="<?php echo e(asset($key->url_img)); ?>" style="">
                                                                   </center>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php if($num==0): ?>
                                                        <div class="col-md-6">
                                                            <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                                                <div class="card-body">
                                                                    <div class="custom-control custom-radio mb-2">
                                                                      <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>" checked>
                                                                    </div>
                                                                   <h3><?php echo e($key->nombre); ?></h3>
                                                                   <span><?php echo e($key->dias); ?> dias</span>
                                                                   <br>
                                                                    <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                                                   <br>
                                                                   <center>
                                                                    <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                                                   </center>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="col-md-6">
                                                            <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                                                <div class="card-body">
                                                                    <div class="custom-control custom-radio mb-2">
                                                                      <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>">
                                                                    </div>
                                                                   <h3><?php echo e($key->nombre); ?></h3>
                                                                   <span><?php echo e($key->dias); ?> dias</span>
                                                                   <br>
                                                                    <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                                                   <br>
                                                                   <center>
                                                                    <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                                                   </center>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php $num++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $planesPago; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($num==0): ?>
                                                <div class="col-md-6">
                                                    <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                                        <div class="card-body">
                                                            <div class="custom-control custom-radio mb-2">
                                                              <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>" checked>
                                                            </div>
                                                           <h3><?php echo e($key->nombre); ?></h3>
                                                           <span><?php echo e($key->dias); ?> dias</span>
                                                           <br>
                                                            <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                                           <br>
                                                           <center>
                                                            <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                                           </center>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div class="col-md-6">
                                                    <div class="card shadow border card-tabla rounded" style="border-color: <?php echo e($key->color); ?> !important; height: 400px;">
                                                        <div class="card-body">
                                                            <div class="custom-control custom-radio mb-2">
                                                              <input type="radio" id="customRadio1" name="planP" value="<?php echo e($key->id); ?>">
                                                            </div>
                                                           <h3><?php echo e($key->nombre); ?></h3>
                                                           <span><?php echo e($key->dias); ?> dias</span>
                                                           <br>
                                                            <span style="font-size: 30px;">$</span><span style="font-size: 70px;"><?php echo e($key->monto); ?></span><strong>/Mes</strong>
                                                           <br>
                                                           <center>
                                                            <img align="center" class="imagenAnun2" src="<?php echo e(asset($key->url_img)); ?>">
                                                           </center>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <?php $num++; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </center>
                          </div>
                        </div>
                        <center>
                            <div class="row">
                                <div class="col-md-12">
                                </div>
                            </div>
                        </center>
                        <div class="float-right">
                            <button type="submit" class="btn btn-success" >Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>


    <?php echo Form::open(['route' => ['anuncios.destroy',1033], 'method' => 'DELETE']); ?>

        <?php echo csrf_field(); ?>
        <div class="modal fade" id="eliminarAnuncio" role="dialog">
            <div class="modal-dialog modals-default">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Eliminar anuncio</h4>                
                        <button type="button" class="close" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <h3>¿Está seguro de querer eliminar el anuncio? Esta opción no se podrá deshacer</h3>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <input type="hidden" class="form-control" name="id" required id="idAnuncio">
                                </div>
                            </div>
                        </div>

                        <div class="float-right">
                            <button type="submit" class="btn btn-danger" >Eliminar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php echo Form::close(); ?>


    





<?php echo $__env->make('root.modales.crearAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('root.modales.eliminarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('root.modales.editarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<script type="text/javascript">
    function bloquear(event) {
        
        if($('input:checkbox[name=todos]').is(':checked')) { 
            console.log('chequeado');
            $('#id_residente').attr('disabled', true);
        } else {  
            console.log('no chequeado');
            $('#id_residente').removeAttr('disabled');
        }
   
    }
</script>
<script type="text/javascript">
    
</script>

<?php $__env->startSection('scripts'); ?>
    <script>
    $(function () {
      $('select').each(function () {
        $(this).select2({
          theme: 'bootstrap4',
          width: 'style',
          placeholder: $(this).attr('placeholder'),
          allowClear: Boolean($(this).data('allow-clear')),
        });
      });
    
    });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\controlapp4.0\resources\views/home.blade.php ENDPATH**/ ?>